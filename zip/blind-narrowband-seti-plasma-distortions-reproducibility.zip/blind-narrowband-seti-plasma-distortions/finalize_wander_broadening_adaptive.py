"""Extend the 30-seed 2-D surface adaptively and write final products."""

from __future__ import annotations

import csv
import json
import shutil
from collections import Counter
from pathlib import Path

import numpy as np

from detector import LinearDriftSearchConfig
from wander_broadening_surface import (
    DEFAULT_OUTPUT_DIR,
    EXPECTED_DETECTOR_SHA256,
    FIXED_THRESHOLD,
    ROOT,
    SIGNAL_AMPLITUDE,
    add_interaction_reference,
    compare_historical_axes,
    grid_arrays,
    plot_interaction_heatmap,
    plot_probability_heatmap,
    plot_representative_spectrograms,
    read_json,
    read_rows,
    run_tasks,
    select_representative_failure,
    summarize_cells,
    validate_fixed_configuration,
    write_json,
    write_probability_table,
    write_rows,
)


BASE_RUNS = 30
TARGET_RUNS = 100
BASE_SEED_START = 900_000
WORKERS = 8
BOUNDARY_CELLS_PER_LEVEL = 8
INTERACTION_CELLS_PER_SIGN = 4
BOOTSTRAP_REPETITIONS = 5000
BOOTSTRAP_SEED = 20260824


def typed_run_rows(path: Path) -> list[dict[str, object]]:
    float_fields = {
        "signal_amplitude",
        "scintillation_strength",
        "wander_scale",
        "wander_rms_Hz",
        "broadening_scale_Hz",
        "effective_width_Hz",
        "best_score",
        "best_f0",
        "best_drift_rate",
        "drift_error",
        "total_injected_signal_power",
        "coherent_signal_power",
        "fixed_threshold",
    }
    int_fields = {"seed", "n_f0_trials", "n_drift_trials", "n_valid_tracks"}
    rows: list[dict[str, object]] = []
    for raw in read_rows(path):
        row: dict[str, object] = {}
        for key, value in raw.items():
            if key in float_fields:
                row[key] = float(value)
            elif key in int_fields:
                row[key] = int(value)
            elif key == "detected":
                row[key] = value.lower() == "true"
            else:
                row[key] = value
        rows.append(row)
    return rows


def typed_summary_rows(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for raw in read_rows(path):
        row: dict[str, object] = {}
        for key, value in raw.items():
            if key == "interaction_ci_excludes_zero":
                row[key] = value.lower() == "true"
            else:
                try:
                    row[key] = float(value)
                except ValueError:
                    row[key] = value
        rows.append(row)
    return rows


def choose_cells(summary: list[dict[str, object]]) -> list[tuple[float, float]]:
    axes = {
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"]))
        for row in summary
        if float(row["wander_scale"]) == 0.0
        or float(row["broadening_scale_Hz"]) == 0.0
    }
    interior = [
        row
        for row in summary
        if float(row["wander_scale"]) > 0.0
        and float(row["broadening_scale_Hz"]) > 0.0
    ]
    selected = set(axes)
    for target in (0.9, 0.5):
        nearest = sorted(
            interior, key=lambda row: abs(float(row["P_detect"]) - target)
        )[:BOUNDARY_CELLS_PER_LEVEL]
        selected.update(
            (float(row["wander_scale"]), float(row["broadening_scale_Hz"]))
            for row in nearest
        )
    negative = sorted(interior, key=lambda row: float(row["interaction_residual"]))[
        :INTERACTION_CELLS_PER_SIGN
    ]
    positive = sorted(
        interior, key=lambda row: float(row["interaction_residual"]), reverse=True
    )[:INTERACTION_CELLS_PER_SIGN]
    selected.update(
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"]))
        for row in negative + positive
    )
    return sorted(selected)


def write_count_table(
    path: Path,
    summary: list[dict[str, object]],
    wander_scales: list[float],
    broadening_scales: list[float],
) -> None:
    lookup = {
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"])): int(
            row["n_trials"]
        )
        for row in summary
    }
    rows: list[dict[str, object]] = []
    for wander in wander_scales:
        row: dict[str, object] = {"wander_scale": wander}
        for broadening in broadening_scales:
            row[f"broadening_{broadening:g}_Hz"] = lookup[(wander, broadening)]
        rows.append(row)
    write_rows(path, rows)


def main() -> None:
    output_dir = DEFAULT_OUTPUT_DIR
    config = LinearDriftSearchConfig()
    detector_hash = validate_fixed_configuration(config)
    if detector_hash != EXPECTED_DETECTOR_SHA256:
        raise RuntimeError("unexpected detector hash")

    base_runs_path = output_dir / "wander_broadening_base30_runs.csv"
    base_summary_path = output_dir / "wander_broadening_base30_cell_summary.csv"
    base_experiment_path = output_dir / "wander_broadening_base30_experiment.json"
    if not base_runs_path.exists():
        shutil.copyfile(output_dir / "wander_broadening_runs.csv", base_runs_path)
        shutil.copyfile(
            output_dir / "wander_broadening_cell_summary.csv", base_summary_path
        )
        shutil.copyfile(
            output_dir / "wander_broadening_experiment.json", base_experiment_path
        )

    base_rows = typed_run_rows(base_runs_path)
    base_summary = typed_summary_rows(
        base_summary_path
    )
    selected_cells = choose_cells(base_summary)
    extra_tasks = [
        (
            "adaptive_extension",
            BASE_SEED_START + seed_offset,
            wander_scale,
            broadening_scale,
            config,
        )
        for wander_scale, broadening_scale in selected_cells
        for seed_offset in range(BASE_RUNS, TARGET_RUNS)
    ]
    extension_path = output_dir / "adaptive_extension_runs.csv"
    if extension_path.exists():
        extra_rows = typed_run_rows(extension_path)
        extension_elapsed = (
            extension_path.stat().st_mtime - base_runs_path.stat().st_mtime
        )
    else:
        extra_rows, extension_elapsed = run_tasks(extra_tasks, WORKERS)
        for row in extra_rows:
            row["fixed_threshold"] = FIXED_THRESHOLD
            row["detected"] = float(row["best_score"]) > FIXED_THRESHOLD
        write_rows(extension_path, extra_rows)

    combined = base_rows + extra_rows
    keys = [
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"]), int(row["seed"]))
        for row in combined
    ]
    if len(keys) != len(set(keys)):
        raise RuntimeError("duplicate cell/seed rows in adaptive merge")
    write_rows(output_dir / "wander_broadening_runs.csv", combined)

    summary = summarize_cells(combined, FIXED_THRESHOLD)
    add_interaction_reference(
        combined, summary, BOOTSTRAP_REPETITIONS, BOOTSTRAP_SEED
    )
    base_power_lookup: dict[tuple[float, float], list[float]] = {}
    for row in base_rows:
        key = (float(row["wander_scale"]), float(row["broadening_scale_Hz"]))
        base_power_lookup.setdefault(key, []).append(
            float(row["total_injected_signal_power"])
        )
    for row in summary:
        key = (float(row["wander_scale"]), float(row["broadening_scale_Hz"]))
        row["common_base30_injected_power_mean"] = float(
            np.mean(base_power_lookup[key])
        )
    write_rows(output_dir / "wander_broadening_cell_summary.csv", summary)
    axis_comparisons = compare_historical_axes(summary)
    write_rows(output_dir / "axis_reproduction.csv", axis_comparisons)

    (
        x_width,
        y_wander,
        probability,
        residual,
        _expected,
        wander_scales,
        broadening_scales,
    ) = grid_arrays(summary)
    write_probability_table(
        output_dir / "detection_probability_table.csv",
        summary,
        wander_scales,
        broadening_scales,
    )
    write_count_table(
        output_dir / "trial_count_table.csv",
        summary,
        wander_scales,
        broadening_scales,
    )
    plot_probability_heatmap(
        x_width,
        y_wander,
        probability,
        output_dir / "detection_probability_heatmap.png",
        add_contours=False,
    )
    contours = plot_probability_heatmap(
        x_width,
        y_wander,
        probability,
        output_dir / "detection_probability_heatmap_with_contours.png",
        add_contours=True,
    )
    write_rows(output_dir / "detection_contour_vertices.csv", contours)
    plot_interaction_heatmap(
        x_width,
        y_wander,
        residual,
        output_dir / "interaction_residual_heatmap.png",
    )
    selection = select_representative_failure(combined, summary)
    plot_representative_spectrograms(
        selection, config, output_dir / "representative_paired_spectrograms.png"
    )
    write_json(output_dir / "representative_cell.json", selection)

    interior = [
        row
        for row in summary
        if float(row["wander_scale"]) > 0.0
        and float(row["broadening_scale_Hz"]) > 0.0
    ]
    most_negative = min(interior, key=lambda row: float(row["interaction_residual"]))
    most_positive = max(interior, key=lambda row: float(row["interaction_residual"]))
    heterogeneous_power_means = np.array(
        [float(row["total_injected_signal_power_mean"]) for row in summary]
    )
    common_base_power_means = np.array(
        [float(row["common_base30_injected_power_mean"]) for row in summary]
    )
    by_seed: dict[int, list[float]] = {}
    for row in combined:
        by_seed.setdefault(int(row["seed"]), []).append(
            float(row["total_injected_signal_power"])
        )
    maximum_paired_power_span = max(
        (max(values) - min(values)) / np.mean(values) for values in by_seed.values()
    )
    cell_counts = Counter(int(row["n_trials"]) for row in summary)
    base_experiment = read_json(base_experiment_path)
    timing_pilot_4 = read_json(output_dir / "surface_pilot.json")
    timing_pilot_8_path = ROOT / "wander_broadening_surface_outputs_8worker_pilot" / "surface_pilot.json"
    timing_pilot_8 = read_json(timing_pilot_8_path) if timing_pilot_8_path.exists() else {}
    timing_seconds = {
        "four_worker_timing_pilot": float(timing_pilot_4["elapsed_seconds"]),
        "eight_worker_timing_pilot": float(timing_pilot_8.get("elapsed_seconds", 0.0)),
        "base_30_seed_surface": float(base_experiment["sweep_elapsed_seconds"]),
        "adaptive_extension": extension_elapsed,
    }
    timing_seconds["total"] = sum(timing_seconds.values())

    selection_rows = [
        {
            "wander_scale": wander,
            "broadening_scale_Hz": broadening,
            "target_trials": TARGET_RUNS,
            "selection_reason": "axis or nearest 0.9/0.5 boundary or extreme pilot residual",
        }
        for wander, broadening in selected_cells
    ]
    write_rows(output_dir / "adaptive_selected_cells.csv", selection_rows)
    payload = {
        "grid_shape": [len(wander_scales), len(broadening_scales)],
        "grid_cells": len(summary),
        "base_runs_per_cell": BASE_RUNS,
        "adaptive_runs_per_selected_cell": TARGET_RUNS,
        "selected_cells_at_100": len(selected_cells),
        "cell_trial_count_distribution": {
            str(key): value for key, value in sorted(cell_counts.items())
        },
        "total_runs": len(combined),
        "adaptive_selection": {
            "all_axis_cells": True,
            "nearest_cells_per_boundary_level": BOUNDARY_CELLS_PER_LEVEL,
            "boundary_levels": [0.9, 0.5],
            "extreme_cells_per_interaction_sign": INTERACTION_CELLS_PER_SIGN,
            "selection_was_based_only_on_30_seed_pilot_surface": True,
        },
        "fixed_threshold": FIXED_THRESHOLD,
        "signal_amplitude": SIGNAL_AMPLITUDE,
        "scintillation_strength": 1.0,
        "detector_sha256": detector_hash,
        "bootstrap_repetitions": BOOTSTRAP_REPETITIONS,
        "bootstrap_method": "paired seed bootstrap using the seed intersection of each cell, its two axis cells, and baseline; percentile 95% CI",
        "independence_reference": "P_expected=P_w*P_b/P0 using paired single-effect axis detections for the same seed subset",
        "contour_interpolation": "Matplotlib linear interpolation within adjacent measured grid cells; no extrapolation",
        "effective_width_definition": "clean-signal STFT power-weighted RMS about deterministic plus injected slow-centroid track, +/-4 Hz",
        "injected_power_definition": "mean(|direct|^2 + |halo|^2 + |delayed|^2)",
        "common_base30_cell_mean_power_relative_span": float(
            (common_base_power_means.max() - common_base_power_means.min())
            / common_base_power_means.mean()
        ),
        "heterogeneous_30_or_100_sample_cell_mean_power_relative_span": float(
            (heterogeneous_power_means.max() - heterogeneous_power_means.min())
            / heterogeneous_power_means.mean()
        ),
        "maximum_per_seed_power_relative_span": float(maximum_paired_power_span),
        "axis_reproduction_all_within_95_percent_sampling": all(
            bool(row["consistent_within_95_percent_sampling"])
            for row in axis_comparisons
        ),
        "axis_reproduction_max_absolute_probability_difference": max(
            abs(float(row["difference"])) for row in axis_comparisons
        ),
        "most_negative_interaction": most_negative,
        "most_positive_interaction": most_positive,
        "representative_cell": selection,
        "runtime_seconds": timing_seconds,
    }
    write_json(output_dir / "wander_broadening_experiment.json", payload)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
