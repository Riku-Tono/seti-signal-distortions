"""Measure blind linear-drift detection efficiency versus centroid wander.

Stages are deliberately separate so the noise-only threshold is fixed before
any signal-present result is inspected:

1. ``benchmark``: time a small noise-only batch.
2. ``noise``: build the full noise-only maximum-score distribution and freeze
   its upper quantiles.
3. ``calibrate``: find a no-wander signal amplitude giving about 90--95%
   detection using the already-frozen 99th-percentile threshold.
4. ``sweep``: hold that amplitude fixed and vary only slow centroid wander.

The imported detector is unchanged and receives only STFT power plus observed
time/frequency axes.  Injected truth is attached after each search for scoring.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
from pathlib import Path
from typing import Iterable

import numpy as np

os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "wander-efficiency-matplotlib")
)
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from detector import LinearDriftSearchConfig, search_linear_drift
from plasma_wandering_signal import (
    INJECTED_DRIFT_RATE_HZ_S,
    centroid_wander_truth,
    simulate,
    stft,
)


DEFAULT_OUTPUT_DIR = Path(__file__).with_name("wander_efficiency_outputs")
NOISE_SUMMARY_NAME = "noise_thresholds.json"


def _blind_search_worker(task: tuple[object, ...]) -> dict[str, object]:
    (
        scenario,
        seed,
        signal_present,
        wander_scale,
        signal_amplitude,
        search_config,
    ) = task
    seed = int(seed)
    signal_present = bool(signal_present)
    wander_scale = float(wander_scale)
    signal_amplitude = float(signal_amplitude)
    assert isinstance(search_config, LinearDriftSearchConfig)

    _time, _true_track, _instantaneous_frequency, received, fs = simulate(
        seed,
        signal_present=signal_present,
        centroid_wander_scale=wander_scale,
        signal_amplitude=signal_amplitude,
    )
    stft_time, frequency, spectrum = stft(received, fs)
    power = np.abs(spectrum) ** 2

    # Blind-search boundary: no truth-valued argument crosses this call.
    result = search_linear_drift(power, stft_time, frequency, search_config)

    # Truth is reconstructed only after the detector result exists.
    if signal_present:
        injected_wander = centroid_wander_truth(seed, wander_scale)
        centered_wander = injected_wander - np.mean(injected_wander)
        wander_rms_hz = float(np.sqrt(np.mean(centered_wander**2)))
        drift_error = result.best_drift_rate - INJECTED_DRIFT_RATE_HZ_S
    else:
        wander_rms_hz = math.nan
        drift_error = math.nan

    return {
        "scenario": str(scenario),
        "seed": seed,
        "signal_present": signal_present,
        "signal_amplitude": signal_amplitude,
        "wander_scale": wander_scale,
        "wander_rms_Hz": wander_rms_hz,
        "best_score": result.best_score,
        "best_f0": result.best_f0,
        "best_drift_rate": result.best_drift_rate,
        "drift_error": drift_error,
        "n_f0_trials": result.n_f0_trials,
        "n_drift_trials": result.n_drift_trials,
        "n_valid_tracks": result.n_valid_tracks,
    }


def run_tasks(
    tasks: list[tuple[object, ...]], workers: int
) -> tuple[list[dict[str, object]], float]:
    started = time.perf_counter()
    if workers == 1:
        rows = [_blind_search_worker(task) for task in tasks]
    else:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            rows = list(executor.map(_blind_search_worker, tasks, chunksize=1))
    return rows, time.perf_counter() - started


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError("cannot write an empty result table")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as output_file:
        writer = csv.DictWriter(output_file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def make_noise_tasks(
    runs: int, seed_start: int, config: LinearDriftSearchConfig
) -> list[tuple[object, ...]]:
    return [
        ("noise_only", seed_start + index, False, 0.0, 0.0, config)
        for index in range(runs)
    ]


def upper_quantiles(scores: np.ndarray) -> dict[str, float]:
    return {
        "percentile_99": float(np.quantile(scores, 0.99, method="linear")),
        "percentile_99_5": float(np.quantile(scores, 0.995, method="linear")),
        "percentile_99_9": float(np.quantile(scores, 0.999, method="linear")),
    }


def wilson_interval(successes: int, trials: int, z: float = 1.959963984540054) -> tuple[float, float]:
    """Two-sided 95% Wilson score interval for a binomial proportion."""
    if trials <= 0:
        raise ValueError("trials must be positive")
    proportion = successes / trials
    denominator = 1.0 + z * z / trials
    center = (proportion + z * z / (2.0 * trials)) / denominator
    radius = (
        z
        * math.sqrt(
            proportion * (1.0 - proportion) / trials
            + z * z / (4.0 * trials * trials)
        )
        / denominator
    )
    return center - radius, center + radius


def summarize_groups(
    rows: list[dict[str, object]], group_key: str, threshold: float
) -> list[dict[str, object]]:
    grouped: dict[float, list[dict[str, object]]] = {}
    for row in rows:
        grouped.setdefault(float(row[group_key]), []).append(row)

    summary: list[dict[str, object]] = []
    for key in sorted(grouped):
        group = grouped[key]
        detected = sum(float(row["best_score"]) > threshold for row in group)
        trials = len(group)
        lower, upper = wilson_interval(detected, trials)
        wander_values = np.array([float(row["wander_rms_Hz"]) for row in group])
        summary.append(
            {
                group_key: key,
                "signal_amplitude": float(group[0]["signal_amplitude"]),
                "detected_count": detected,
                "trial_count": trials,
                "detection_probability": detected / trials,
                "wilson_95_low": lower,
                "wilson_95_high": upper,
                "wander_rms_Hz_mean": float(np.mean(wander_values)),
                "wander_rms_Hz_std": float(np.std(wander_values, ddof=1)) if trials > 1 else 0.0,
                "best_score_mean": float(np.mean([float(row["best_score"]) for row in group])),
                "drift_error_rmse": float(
                    np.sqrt(np.mean([float(row["drift_error"]) ** 2 for row in group]))
                ),
            }
        )
    return summary


def interpolate_downward_crossing(
    x_values: Iterable[float], probabilities: Iterable[float], target: float
) -> float | None:
    points = sorted(zip(x_values, probabilities))
    for (x0, p0), (x1, p1) in zip(points, points[1:]):
        if p0 == target:
            return float(x0)
        if (p0 - target) * (p1 - target) <= 0.0 and p0 != p1:
            fraction = (target - p0) / (p1 - p0)
            return float(x0 + fraction * (x1 - x0))
    if points and points[-1][1] == target:
        return float(points[-1][0])
    return None


def make_efficiency_plot(
    summary: list[dict[str, object]],
    x_key: str,
    xlabel: str,
    output_path: Path,
    crossings: dict[str, float | None],
) -> None:
    x = np.array([float(row[x_key]) for row in summary])
    p = np.array([float(row["detection_probability"]) for row in summary])
    low = np.array([float(row["wilson_95_low"]) for row in summary])
    high = np.array([float(row["wilson_95_high"]) for row in summary])

    fig, axis = plt.subplots(figsize=(8.8, 5.8))
    axis.errorbar(
        x,
        p,
        yerr=np.vstack((p - low, high - p)),
        fmt="o-",
        color="#2563eb",
        ecolor="#60a5fa",
        capsize=4,
        linewidth=1.8,
        markersize=6,
        label="Detection efficiency (95% Wilson interval)",
    )
    for target, color in ((0.9, "#d97706"), (0.5, "#dc2626")):
        axis.axhline(target, color=color, linestyle="--", linewidth=1.1, alpha=0.8)
        crossing = crossings.get(str(target))
        if crossing is not None:
            axis.axvline(crossing, color=color, linestyle=":", linewidth=1.1, alpha=0.8)
    axis.set_xlabel(xlabel)
    axis.set_ylabel("Detection probability")
    axis.set_ylim(-0.03, 1.03)
    axis.set_title("Blind linear-drift detection efficiency")
    axis.grid(alpha=0.22)
    axis.legend(loc="best")
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def stage_benchmark(args: argparse.Namespace, config: LinearDriftSearchConfig) -> None:
    tasks = make_noise_tasks(args.runs, args.seed_start, config)
    rows, elapsed = run_tasks(tasks, args.workers)
    output_dir = args.output_dir
    write_rows(output_dir / "noise_benchmark_scores.csv", rows)
    payload = {
        "runs": args.runs,
        "workers": args.workers,
        "elapsed_seconds": elapsed,
        "seconds_per_realization_wall": elapsed / args.runs,
        "projected_1000_seconds": elapsed * 1000.0 / args.runs,
        "search_config": asdict(config),
    }
    write_json(output_dir / "noise_benchmark.json", payload)
    print(json.dumps(payload, indent=2))


def stage_noise(args: argparse.Namespace, config: LinearDriftSearchConfig) -> None:
    tasks = make_noise_tasks(args.runs, args.seed_start, config)
    rows, elapsed = run_tasks(tasks, args.workers)
    scores = np.array([float(row["best_score"]) for row in rows])
    quantiles = upper_quantiles(scores)
    threshold = quantiles["percentile_99"]
    false_positives = int(np.sum(scores > threshold))
    for row in rows:
        row["threshold_99"] = threshold
        row["false_positive"] = float(row["best_score"]) > threshold
    write_rows(args.output_dir / "noise_only_best_scores.csv", rows)
    payload = {
        "runs": args.runs,
        "workers": args.workers,
        "elapsed_seconds": elapsed,
        "score_mean": float(np.mean(scores)),
        "score_std": float(np.std(scores, ddof=1)),
        **quantiles,
        "fixed_threshold": threshold,
        "fixed_threshold_percentile": 99.0,
        "empirical_false_positive_count": false_positives,
        "empirical_false_positive_rate": false_positives / args.runs,
        "search_config": asdict(config),
    }
    write_json(args.output_dir / NOISE_SUMMARY_NAME, payload)
    print(json.dumps(payload, indent=2))


def stage_calibrate(args: argparse.Namespace, config: LinearDriftSearchConfig) -> None:
    noise_summary = read_json(args.output_dir / NOISE_SUMMARY_NAME)
    threshold = float(noise_summary["fixed_threshold"])
    amplitudes = [float(value) for value in args.amplitudes]
    tasks: list[tuple[object, ...]] = []
    for amplitude in amplitudes:
        for index in range(args.runs):
            tasks.append(
                (
                    f"amplitude_{amplitude:g}",
                    args.seed_start + index,
                    True,
                    0.0,
                    amplitude,
                    config,
                )
            )
    rows, elapsed = run_tasks(tasks, args.workers)
    for row in rows:
        row["fixed_threshold"] = threshold
        row["detected"] = float(row["best_score"]) > threshold
    write_rows(args.output_dir / "amplitude_calibration_runs.csv", rows)
    summary = summarize_groups(rows, "signal_amplitude", threshold)
    write_rows(args.output_dir / "amplitude_calibration_summary.csv", summary)
    chosen = min(
        summary,
        key=lambda row: abs(float(row["detection_probability"]) - 0.925),
    )
    payload = {
        "runs_per_amplitude": args.runs,
        "workers": args.workers,
        "elapsed_seconds": elapsed,
        "fixed_threshold": threshold,
        "target_detection_probability": 0.925,
        "chosen_signal_amplitude": float(chosen["signal_amplitude"]),
        "chosen_detection_probability": float(chosen["detection_probability"]),
        "chosen_is_within_90_95_percent": 0.90
        <= float(chosen["detection_probability"])
        <= 0.95,
        "candidate_summaries": summary,
    }
    write_json(args.output_dir / "amplitude_calibration.json", payload)
    print(json.dumps(payload, indent=2))


def stage_sweep(args: argparse.Namespace, config: LinearDriftSearchConfig) -> None:
    noise_summary = read_json(args.output_dir / NOISE_SUMMARY_NAME)
    threshold = float(noise_summary["fixed_threshold"])
    amplitude = float(args.signal_amplitude)
    scales = [float(value) for value in args.wander_scales]

    tasks: list[tuple[object, ...]] = []
    for scale in scales:
        for index in range(args.runs):
            # Identical seed set for every scale: all unscaled stochastic draws
            # are paired, and only the slow-centroid multiplier changes.
            tasks.append(
                (
                    "wander_sweep",
                    args.seed_start + index,
                    True,
                    scale,
                    amplitude,
                    config,
                )
            )
    rows, elapsed = run_tasks(tasks, args.workers)
    for row in rows:
        row["fixed_threshold"] = threshold
        row["detected"] = float(row["best_score"]) > threshold
    write_rows(args.output_dir / "wander_sweep_results.csv", rows)
    summary = summarize_groups(rows, "wander_scale", threshold)
    write_rows(args.output_dir / "wander_efficiency_summary.csv", summary)

    probabilities = [float(row["detection_probability"]) for row in summary]
    scale_values = [float(row["wander_scale"]) for row in summary]
    rms_values = [float(row["wander_rms_Hz_mean"]) for row in summary]
    scale_crossings = {
        str(target): interpolate_downward_crossing(scale_values, probabilities, target)
        for target in (0.9, 0.5)
    }
    rms_crossings = {
        str(target): interpolate_downward_crossing(rms_values, probabilities, target)
        for target in (0.9, 0.5)
    }

    make_efficiency_plot(
        summary,
        "wander_scale",
        "Centroid wander scale",
        args.output_dir / "detection_efficiency_vs_wander_scale.png",
        scale_crossings,
    )
    make_efficiency_plot(
        summary,
        "wander_rms_Hz_mean",
        "Injected centroid wander RMS (Hz)",
        args.output_dir / "detection_efficiency_vs_wander_rms_Hz.png",
        rms_crossings,
    )

    calibration_path = args.output_dir / "amplitude_calibration.json"
    calibration = read_json(calibration_path) if calibration_path.exists() else {}
    calibration_round1_path = args.output_dir / "amplitude_calibration_round1.json"
    calibration_round1 = (
        read_json(calibration_round1_path) if calibration_round1_path.exists() else {}
    )
    benchmark_path = args.output_dir / "noise_benchmark.json"
    benchmark = read_json(benchmark_path) if benchmark_path.exists() else {}
    total_experiment_seconds = (
        float(noise_summary.get("elapsed_seconds", 0.0))
        + float(calibration_round1.get("elapsed_seconds", 0.0))
        + float(calibration.get("elapsed_seconds", 0.0))
        + elapsed
    )
    total_with_benchmark = total_experiment_seconds + float(
        benchmark.get("elapsed_seconds", 0.0)
    )
    payload = {
        "fixed_threshold": threshold,
        "noise_only_runs": int(noise_summary["runs"]),
        "noise_percentiles": {
            "99": noise_summary["percentile_99"],
            "99.5": noise_summary["percentile_99_5"],
            "99.9": noise_summary["percentile_99_9"],
        },
        "noise_false_positive_rate": noise_summary["empirical_false_positive_rate"],
        "signal_amplitude": amplitude,
        "runs_per_wander_scale": args.runs,
        "wilson_interval_confidence": 0.95,
        "wander_rms_definition": "sqrt(mean((slow_centroid_wander - its_mean)^2))",
        "scale_crossings": scale_crossings,
        "wander_rms_Hz_crossings": rms_crossings,
        "sweep_elapsed_seconds": elapsed,
        "total_experiment_seconds_excluding_benchmark": total_experiment_seconds,
        "benchmark_elapsed_seconds": benchmark.get("elapsed_seconds"),
        "total_execution_seconds_including_benchmark": total_with_benchmark,
        "summary": summary,
    }
    write_json(args.output_dir / "wander_efficiency_experiment.json", payload)
    print(json.dumps(payload, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "stage", choices=("benchmark", "noise", "calibrate", "sweep")
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument("--runs", type=int)
    parser.add_argument("--seed-start", type=int)
    parser.add_argument("--amplitudes", nargs="+", type=float)
    parser.add_argument("--signal-amplitude", type=float)
    parser.add_argument("--wander-scales", nargs="+", type=float)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be at least 1")

    defaults = {
        "benchmark": (100, 50_000),
        "noise": (1000, 100_000),
        "calibrate": (60, 200_000),
        "sweep": (100, 300_000),
    }
    default_runs, default_seed = defaults[args.stage]
    args.runs = default_runs if args.runs is None else args.runs
    args.seed_start = default_seed if args.seed_start is None else args.seed_start
    if args.runs < 1:
        parser.error("--runs must be positive")

    config = LinearDriftSearchConfig()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    if args.stage == "benchmark":
        stage_benchmark(args, config)
    elif args.stage == "noise":
        stage_noise(args, config)
    elif args.stage == "calibrate":
        if not args.amplitudes:
            parser.error("calibrate requires --amplitudes")
        stage_calibrate(args, config)
    elif args.stage == "sweep":
        if args.signal_amplitude is None:
            parser.error("sweep requires --signal-amplitude")
        if not args.wander_scales:
            parser.error("sweep requires --wander-scales")
        stage_sweep(args, config)


if __name__ == "__main__":
    main()
