"""Measure blind linear-drift efficiency versus spectral broadening only.

Slow centroid wander is fixed to zero.  The signal amplitude, scintillation,
baseline fast fluctuations, scattering halo, multipath, receiver noise, STFT,
and blind-detector grid match the completed wander experiment.  Additional
zero-mean fast phase modulation redistributes fixed signal power in frequency.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
from pathlib import Path

import numpy as np

os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "broadening-efficiency-matplotlib")
)
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from detector import LinearDriftSearchConfig, search_linear_drift
from plasma_wandering_signal import INJECTED_DRIFT_RATE_HZ_S, simulate, stft
from wander_efficiency import interpolate_downward_crossing, wilson_interval


ROOT = Path(__file__).parent
DEFAULT_OUTPUT_DIR = ROOT / "broadening_efficiency_outputs"
WANDER_OUTPUT_DIR = ROOT / "wander_efficiency_outputs"
SIGNAL_AMPLITUDE = 0.034


def measure_effective_width_hz(
    signal_only: np.ndarray,
    fs: float,
    deterministic_time: np.ndarray,
    deterministic_frequency: np.ndarray,
    measurement_half_width_hz: float = 4.0,
) -> float:
    """Truth-side power-weighted RMS width around the linear Doppler track.

    The clean injected signal is transformed using the same STFT settings as
    the detector.  Power within +/-4 Hz of the deterministic track is pooled
    over all time columns, then its second moment about that track is measured.
    This function is called only after blind detection has completed.
    """
    stft_time, frequency, spectrum = stft(signal_only, fs)
    power = np.abs(spectrum) ** 2
    track = np.interp(stft_time, deterministic_time, deterministic_frequency)
    numerator = 0.0
    denominator = 0.0
    for column, center_frequency in enumerate(track):
        offset = frequency - center_frequency
        local = np.abs(offset) <= measurement_half_width_hz
        local_power = power[local, column]
        local_offset = offset[local]
        numerator += float(np.sum(local_power * local_offset**2))
        denominator += float(np.sum(local_power))
    if denominator <= 0.0:
        return math.nan
    return math.sqrt(numerator / denominator)


def _worker(task: tuple[object, ...]) -> dict[str, object]:
    stage, seed, broadening_sigma_hz, signal_amplitude, config = task
    seed = int(seed)
    broadening_sigma_hz = float(broadening_sigma_hz)
    signal_amplitude = float(signal_amplitude)
    assert isinstance(config, LinearDriftSearchConfig)

    simulation = simulate(
        seed,
        centroid_wander_scale=0.0,
        signal_present=True,
        signal_amplitude=signal_amplitude,
        broadening_sigma_hz=broadening_sigma_hz,
        return_truth=True,
    )
    time_axis, deterministic_frequency, _instantaneous, received, fs, truth = simulation
    stft_time, frequency, spectrum = stft(received, fs)
    power = np.abs(spectrum) ** 2

    # Blind boundary: detector receives no injected track or width information.
    result = search_linear_drift(power, stft_time, frequency, config)

    # Truth-side measurements happen strictly after the detector result exists.
    signal_only = np.asarray(truth["signal_only"])
    effective_width_hz = measure_effective_width_hz(
        signal_only,
        fs,
        time_axis,
        deterministic_frequency,
    )
    extra_frequency = np.asarray(truth["extra_broadening_frequency_hz"])
    injected_extra_rms_hz = float(
        np.sqrt(np.mean((extra_frequency - np.mean(extra_frequency)) ** 2))
    )

    return {
        "stage": str(stage),
        "seed": seed,
        "signal_present": True,
        "signal_amplitude": signal_amplitude,
        "broadening_scale": broadening_sigma_hz,
        "injected_extra_frequency_rms_Hz": injected_extra_rms_hz,
        "effective_width_Hz": effective_width_hz,
        "total_injected_signal_power": float(truth["injected_component_power"]),
        "coherent_signal_power": float(truth["coherent_signal_power"]),
        "best_score": result.best_score,
        "best_f0": result.best_f0,
        "best_drift_rate": result.best_drift_rate,
        "drift_error": result.best_drift_rate - INJECTED_DRIFT_RATE_HZ_S,
        "n_f0_trials": result.n_f0_trials,
        "n_drift_trials": result.n_drift_trials,
        "n_valid_tracks": result.n_valid_tracks,
    }


def run_tasks(
    tasks: list[tuple[object, ...]], workers: int
) -> tuple[list[dict[str, object]], float]:
    started = time.perf_counter()
    if workers == 1:
        rows = [_worker(task) for task in tasks]
    else:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            rows = list(executor.map(_worker, tasks, chunksize=1))
    return rows, time.perf_counter() - started


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError("cannot write an empty table")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as output_file:
        writer = csv.DictWriter(output_file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def validate_reused_threshold(config: LinearDriftSearchConfig) -> tuple[float, dict[str, object]]:
    threshold_metadata = read_json(WANDER_OUTPUT_DIR / "noise_thresholds.json")
    stored_config = threshold_metadata["search_config"]
    if stored_config != asdict(config):
        raise RuntimeError("search grid changed; noise threshold cannot be reused")
    threshold = float(threshold_metadata["fixed_threshold"])
    if not math.isclose(threshold, 156666.25361187334, rel_tol=0.0, abs_tol=1e-8):
        raise RuntimeError("stored threshold differs from completed wander experiment")
    return threshold, threshold_metadata


def summarize(
    rows: list[dict[str, object]], threshold: float
) -> list[dict[str, object]]:
    grouped: dict[float, list[dict[str, object]]] = {}
    for row in rows:
        grouped.setdefault(float(row["broadening_scale"]), []).append(row)

    baseline_power: float | None = None
    summaries: list[dict[str, object]] = []
    for scale in sorted(grouped):
        group = grouped[scale]
        count = len(group)
        detected = sum(float(row["best_score"]) > threshold for row in group)
        low, high = wilson_interval(detected, count)
        widths = np.array([float(row["effective_width_Hz"]) for row in group])
        powers = np.array([float(row["total_injected_signal_power"]) for row in group])
        coherent_powers = np.array([float(row["coherent_signal_power"]) for row in group])
        mean_power = float(np.mean(powers))
        if baseline_power is None:
            baseline_power = mean_power
        summaries.append(
            {
                "broadening_scale": scale,
                "signal_amplitude": float(group[0]["signal_amplitude"]),
                "detected_count": detected,
                "trial_count": count,
                "detection_probability": detected / count,
                "wilson_95_low": low,
                "wilson_95_high": high,
                "effective_width_Hz_mean": float(np.mean(widths)),
                "effective_width_Hz_std": float(np.std(widths, ddof=1)),
                "total_injected_signal_power_mean": mean_power,
                "total_injected_signal_power_relative_to_baseline": mean_power / baseline_power,
                "coherent_signal_power_mean": float(np.mean(coherent_powers)),
                "best_score_mean": float(np.mean([float(row["best_score"]) for row in group])),
                "drift_error_rmse": float(
                    np.sqrt(np.mean([float(row["drift_error"]) ** 2 for row in group]))
                ),
            }
        )
    return summaries


def plot_curve(
    summary: list[dict[str, object]],
    x_key: str,
    xlabel: str,
    path: Path,
    crossings: dict[str, float | None],
) -> None:
    x = np.array([float(row[x_key]) for row in summary])
    p = np.array([float(row["detection_probability"]) for row in summary])
    low = np.array([float(row["wilson_95_low"]) for row in summary])
    high = np.array([float(row["wilson_95_high"]) for row in summary])
    fig, axis = plt.subplots(figsize=(8.8, 5.8))
    axis.errorbar(
        x,
        p,
        yerr=np.vstack((p - low, high - p)),
        fmt="o-",
        color="#7c3aed",
        ecolor="#a78bfa",
        capsize=4,
        linewidth=1.8,
        label="Spectral broadening (95% Wilson interval)",
    )
    for target, color in ((0.9, "#d97706"), (0.5, "#dc2626")):
        axis.axhline(target, color=color, linestyle="--", linewidth=1.1, alpha=0.8)
        crossing = crossings[str(target)]
        if crossing is not None:
            axis.axvline(crossing, color=color, linestyle=":", linewidth=1.1, alpha=0.8)
    axis.set_xlabel(xlabel)
    axis.set_ylabel("Detection probability")
    axis.set_ylim(-0.03, 1.03)
    axis.set_title("Blind linear-drift efficiency vs spectral broadening")
    axis.grid(alpha=0.22)
    axis.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def plot_comparison(
    broadening_summary: list[dict[str, object]], path: Path
) -> None:
    wander_rows: list[dict[str, str]] = []
    with (WANDER_OUTPUT_DIR / "wander_efficiency_summary.csv").open(
        newline="", encoding="utf-8"
    ) as input_file:
        wander_rows = list(csv.DictReader(input_file))

    bx = np.array([float(row["effective_width_Hz_mean"]) for row in broadening_summary])
    bp = np.array([float(row["detection_probability"]) for row in broadening_summary])
    blow = np.array([float(row["wilson_95_low"]) for row in broadening_summary])
    bhigh = np.array([float(row["wilson_95_high"]) for row in broadening_summary])
    wx = np.array([float(row["wander_rms_Hz_mean"]) for row in wander_rows])
    wp = np.array([float(row["detection_probability"]) for row in wander_rows])
    wlow = np.array([float(row["wilson_95_low"]) for row in wander_rows])
    whigh = np.array([float(row["wilson_95_high"]) for row in wander_rows])

    fig, axis = plt.subplots(figsize=(9.4, 6.2))
    axis.errorbar(
        wx,
        wp,
        yerr=np.vstack((wp - wlow, whigh - wp)),
        fmt="o-",
        color="#2563eb",
        capsize=3,
        label="Centroid wander RMS",
    )
    axis.errorbar(
        bx,
        bp,
        yerr=np.vstack((bp - blow, bhigh - bp)),
        fmt="s-",
        color="#7c3aed",
        capsize=3,
        label="Effective spectral RMS width",
    )
    axis.set_xlabel("Frequency-scale metric (Hz; distinct physical meanings)")
    axis.set_ylabel("Detection probability")
    axis.set_ylim(-0.03, 1.03)
    axis.set_title("Blind detector response: centroid wander vs spectral width")
    axis.grid(alpha=0.22)
    axis.legend()
    axis.text(
        0.01,
        0.02,
        "Caution: wander RMS measures track displacement; spectral RMS measures power spread.\n"
        "Equal numerical Hz values are not physically equivalent perturbations.",
        transform=axis.transAxes,
        fontsize=9,
        color="#374151",
    )
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def run_stage(args: argparse.Namespace) -> None:
    config = LinearDriftSearchConfig()
    threshold, threshold_metadata = validate_reused_threshold(config)
    widths = [float(value) for value in args.widths]
    tasks = [
        (
            args.stage,
            args.seed_start + index,
            width,
            SIGNAL_AMPLITUDE,
            config,
        )
        for width in widths
        for index in range(args.runs)
    ]
    rows, elapsed = run_tasks(tasks, args.workers)
    for row in rows:
        row["fixed_threshold"] = threshold
        row["detected"] = float(row["best_score"]) > threshold

    output_dir = args.output_dir
    if args.stage == "pilot":
        write_rows(output_dir / "broadening_pilot_runs.csv", rows)
        summary = summarize(rows, threshold)
        write_rows(output_dir / "broadening_pilot_summary.csv", summary)
        payload = {
            "runs_per_condition": args.runs,
            "elapsed_seconds": elapsed,
            "fixed_threshold": threshold,
            "signal_amplitude": SIGNAL_AMPLITUDE,
            "summary": summary,
        }
        write_json(output_dir / "broadening_pilot.json", payload)
        print(json.dumps(payload, indent=2))
        return

    write_rows(output_dir / "broadening_sweep_results.csv", rows)
    summary = summarize(rows, threshold)
    write_rows(output_dir / "broadening_efficiency_summary.csv", summary)

    probabilities = [float(row["detection_probability"]) for row in summary]
    scale_values = [float(row["broadening_scale"]) for row in summary]
    width_values = [float(row["effective_width_Hz_mean"]) for row in summary]
    scale_crossings = {
        str(target): interpolate_downward_crossing(scale_values, probabilities, target)
        for target in (0.9, 0.5)
    }
    width_crossings = {
        str(target): interpolate_downward_crossing(width_values, probabilities, target)
        for target in (0.9, 0.5)
    }

    plot_curve(
        summary,
        "broadening_scale",
        "Additional broadening frequency RMS (Hz)",
        output_dir / "detection_efficiency_vs_broadening_scale.png",
        scale_crossings,
    )
    plot_curve(
        summary,
        "effective_width_Hz_mean",
        "Measured effective spectral RMS width (Hz)",
        output_dir / "detection_efficiency_vs_effective_width_Hz.png",
        width_crossings,
    )
    plot_comparison(summary, output_dir / "wander_vs_broadening_comparison.png")

    pilot_path = output_dir / "broadening_pilot.json"
    pilot = read_json(pilot_path) if pilot_path.exists() else {}
    powers = np.array(
        [float(row["total_injected_signal_power_mean"]) for row in summary]
    )
    relative_span = float((powers.max() - powers.min()) / powers[0])
    payload = {
        "fixed_threshold": threshold,
        "threshold_source": str(WANDER_OUTPUT_DIR / "noise_thresholds.json"),
        "threshold_noise_runs": threshold_metadata["runs"],
        "signal_amplitude": SIGNAL_AMPLITUDE,
        "slow_centroid_wander_scale": 0.0,
        "runs_per_condition": args.runs,
        "wilson_interval_confidence": 0.95,
        "effective_width_definition": "power-weighted RMS about deterministic track, clean-signal STFT, +/-4 Hz",
        "injected_power_definition": "mean(|direct|^2 + |halo|^2 + |delayed|^2)",
        "injected_power_relative_span": relative_span,
        "scale_crossings": scale_crossings,
        "effective_width_Hz_crossings": width_crossings,
        "pilot_elapsed_seconds": pilot.get("elapsed_seconds"),
        "sweep_elapsed_seconds": elapsed,
        "total_execution_seconds": elapsed + float(pilot.get("elapsed_seconds", 0.0)),
        "summary": summary,
    }
    write_json(output_dir / "broadening_efficiency_experiment.json", payload)
    print(json.dumps(payload, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("pilot", "sweep"))
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument("--runs", type=int)
    parser.add_argument("--seed-start", type=int)
    parser.add_argument(
        "--widths",
        nargs="+",
        type=float,
        default=[0.0, 0.05, 0.10, 0.20, 0.30, 0.50, 0.75, 1.0],
    )
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    if args.runs is None:
        args.runs = 10 if args.stage == "pilot" else 100
    if args.seed_start is None:
        args.seed_start = 400_000 if args.stage == "pilot" else 500_000
    if args.runs < 1:
        parser.error("--runs must be positive")
    if any(width < 0.0 for width in args.widths):
        parser.error("widths must be non-negative")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    run_stage(args)


if __name__ == "__main__":
    main()
