"""Small blind-detector sanity check: no centroid wander vs current wander.

This is deliberately not a large Monte Carlo sweep.  It runs 20 independent
noise-only calibrations and 20 paired seeds for each signal condition.  The
detector never receives injected truth; truth is attached only after each
search to calculate ``drift_error`` for evaluation.
"""

from __future__ import annotations

import argparse
import csv
import os
import tempfile
import time
from pathlib import Path

import numpy as np

os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "plasma-detector-matplotlib")
)
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from detector import (
    LinearDriftSearchConfig,
    estimate_noise_normalization,
    normalize_best_score,
    search_linear_drift,
)
from plasma_wandering_signal import INJECTED_DRIFT_RATE_HZ_S, simulate, stft


def run_blind_search(
    seed: int,
    *,
    signal_present: bool,
    centroid_wander_scale: float,
    search_config: LinearDriftSearchConfig,
) -> dict[str, float | int | bool]:
    """Simulate, make an STFT, and search without passing truth to detector."""
    _time, _truth_track, _instantaneous_frequency, received, fs = simulate(
        seed,
        signal_present=signal_present,
        centroid_wander_scale=centroid_wander_scale,
    )
    stft_time, frequency, spectrum = stft(received, fs)
    power = np.abs(spectrum) ** 2

    # Only observed data products and the fixed search grid cross this boundary.
    result = search_linear_drift(power, stft_time, frequency, search_config)
    return {
        "seed": seed,
        "signal_present": signal_present,
        "best_score": result.best_score,
        "best_f0": result.best_f0,
        "best_drift_rate": result.best_drift_rate,
        "n_f0_trials": result.n_f0_trials,
        "n_drift_trials": result.n_drift_trials,
        "n_valid_tracks": result.n_valid_tracks,
    }


def make_distribution_figure(rows: list[dict[str, object]], output_path: Path) -> None:
    no_wander = np.array(
        [float(row["detection_statistic"]) for row in rows if row["scenario"] == "no_wander"]
    )
    current_wander = np.array(
        [float(row["detection_statistic"]) for row in rows if row["scenario"] == "current_wander"]
    )

    all_values = np.concatenate((no_wander, current_wander))
    lower = float(np.floor(all_values.min()))
    upper = float(np.ceil(all_values.max()))
    if upper <= lower:
        upper = lower + 1.0
    bins = np.linspace(lower, upper, 13)

    fig, axis = plt.subplots(figsize=(9.2, 5.6))
    axis.hist(
        no_wander,
        bins=bins,
        alpha=0.68,
        color="#268bd2",
        edgecolor="white",
        label=f"No centroid wander (n={no_wander.size})",
    )
    axis.hist(
        current_wander,
        bins=bins,
        alpha=0.68,
        color="#dc322f",
        edgecolor="white",
        label=f"Current centroid wander (n={current_wander.size})",
    )
    axis.axvline(np.mean(no_wander), color="#075985", linestyle="--", linewidth=1.8)
    axis.axvline(
        np.mean(current_wander), color="#991b1b", linestyle="--", linewidth=1.8
    )
    axis.set_xlabel("Detection statistic: (best score - noise mean) / noise std")
    axis.set_ylabel("Run count")
    axis.set_title("Blind linear-drift detector sanity check")
    axis.grid(alpha=0.2)
    axis.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=20, help="Runs per condition.")
    parser.add_argument(
        "--output-dir", type=Path, default=Path(__file__).with_name("sanity_outputs")
    )
    args = parser.parse_args()
    if args.runs < 2:
        raise ValueError("--runs must be at least 2 for noise normalization")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    config = LinearDriftSearchConfig()
    started = time.perf_counter()

    raw_rows: list[dict[str, object]] = []
    # A disjoint seed block makes the null calibration independent of signals.
    for index in range(args.runs):
        row = run_blind_search(
            10_000 + index,
            signal_present=False,
            centroid_wander_scale=0.0,
            search_config=config,
        )
        row["scenario"] = "noise_only"
        raw_rows.append(row)

    noise_scores = np.array(
        [float(row["best_score"]) for row in raw_rows if row["scenario"] == "noise_only"]
    )
    normalization = estimate_noise_normalization(noise_scores)

    # Paired signal seeds: all random draws other than the scaled slow centroid
    # wandering are identical between A and B.
    for index in range(args.runs):
        seed = 1_000 + index
        for scenario, wander_scale in (("no_wander", 0.0), ("current_wander", 1.0)):
            row = run_blind_search(
                seed,
                signal_present=True,
                centroid_wander_scale=wander_scale,
                search_config=config,
            )
            row["scenario"] = scenario
            raw_rows.append(row)

    for row in raw_rows:
        row["detection_statistic"] = normalize_best_score(
            float(row["best_score"]), normalization
        )
        # Post-search scoring only.  This value never enters search_linear_drift.
        row["injected_drift_rate"] = (
            INJECTED_DRIFT_RATE_HZ_S if bool(row["signal_present"]) else np.nan
        )
        row["drift_error"] = (
            float(row["best_drift_rate"]) - INJECTED_DRIFT_RATE_HZ_S
            if bool(row["signal_present"])
            else np.nan
        )
        row["noise_mean"] = normalization.mean
        row["noise_std"] = normalization.std

    csv_path = args.output_dir / "sanity_check_results.csv"
    fieldnames = [
        "scenario",
        "seed",
        "signal_present",
        "best_score",
        "detection_statistic",
        "best_f0",
        "best_drift_rate",
        "injected_drift_rate",
        "drift_error",
        "noise_mean",
        "noise_std",
        "n_f0_trials",
        "n_drift_trials",
        "n_valid_tracks",
    ]
    with csv_path.open("w", newline="", encoding="utf-8") as output_file:
        writer = csv.DictWriter(output_file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(raw_rows)

    figure_path = args.output_dir / "detection_statistic_distribution.png"
    make_distribution_figure(raw_rows, figure_path)

    elapsed = time.perf_counter() - started
    summary_path = args.output_dir / "sanity_check_summary.txt"
    condition_rows = {
        scenario: [row for row in raw_rows if row["scenario"] == scenario]
        for scenario in ("noise_only", "no_wander", "current_wander")
    }
    lines = [
        f"runs_per_condition={args.runs}",
        f"f0_trials={raw_rows[0]['n_f0_trials']}",
        f"drift_trials={raw_rows[0]['n_drift_trials']}",
        f"f0_step_hz={config.f0_step_hz}",
        f"drift_step_hz_s={config.drift_step_hz_s}",
        f"noise_mean={normalization.mean:.8f}",
        f"noise_std={normalization.std:.8f}",
        f"elapsed_seconds={elapsed:.3f}",
    ]
    for scenario, scenario_rows in condition_rows.items():
        statistics = np.array([float(row["detection_statistic"]) for row in scenario_rows])
        lines.append(f"{scenario}_stat_mean={statistics.mean():.6f}")
        lines.append(f"{scenario}_stat_std={statistics.std(ddof=1):.6f}")
        if scenario != "noise_only":
            drift_errors = np.array([float(row["drift_error"]) for row in scenario_rows])
            lines.append(f"{scenario}_drift_error_mean={drift_errors.mean():.6f}")
            lines.append(f"{scenario}_drift_error_rmse={np.sqrt(np.mean(drift_errors**2)):.6f}")
    summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("\n".join(lines))
    print(f"saved: {csv_path.resolve()}")
    print(f"saved: {figure_path.resolve()}")
    print(f"saved: {summary_path.resolve()}")


if __name__ == "__main__":
    main()
