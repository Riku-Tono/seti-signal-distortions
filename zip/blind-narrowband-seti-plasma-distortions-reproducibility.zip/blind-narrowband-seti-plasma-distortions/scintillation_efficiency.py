"""Measure blind linear-drift efficiency versus scintillation strength only.

Slow centroid wander and additional spectral broadening are fixed to zero.  The
existing lognormal amplitude realization is scaled in strength and normalized
per paired seed so its time-mean intensity remains fixed across all conditions.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
from pathlib import Path

import numpy as np

os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "scintillation-efficiency-matplotlib")
)
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from detector import LinearDriftSearchConfig, search_linear_drift
from plasma_wandering_signal import INJECTED_DRIFT_RATE_HZ_S, simulate, stft
from wander_efficiency import interpolate_downward_crossing, wilson_interval


ROOT = Path(__file__).parent
DEFAULT_OUTPUT_DIR = ROOT / "scintillation_efficiency_outputs"
WANDER_OUTPUT_DIR = ROOT / "wander_efficiency_outputs"
BROADENING_OUTPUT_DIR = ROOT / "broadening_efficiency_outputs"
SIGNAL_AMPLITUDE = 0.034


def _worker(task: tuple[object, ...]) -> dict[str, object]:
    stage, seed, strength, signal_amplitude, config = task
    seed = int(seed)
    strength = float(strength)
    signal_amplitude = float(signal_amplitude)
    assert isinstance(config, LinearDriftSearchConfig)

    simulation = simulate(
        seed,
        centroid_wander_scale=0.0,
        broadening_sigma_hz=0.0,
        scintillation_strength=strength,
        signal_present=True,
        signal_amplitude=signal_amplitude,
        return_truth=True,
    )
    _time, _deterministic, _instantaneous, received, fs, truth = simulation
    stft_time, frequency, spectrum = stft(received, fs)
    power = np.abs(spectrum) ** 2

    # Blind boundary: no truth-valued quantity enters this call.
    result = search_linear_drift(power, stft_time, frequency, config)

    # Truth-side metrics are attached only after blind detection returns.
    intensity = np.asarray(truth["scintillation_intensity"], dtype=float)
    mean_intensity = float(np.mean(intensity))
    modulation_index = float(np.std(intensity) / mean_intensity)
    occupancy_above_mean = (
        1.0
        if modulation_index < 1e-12
        else float(np.mean(intensity >= mean_intensity))
    )
    direct = np.asarray(truth["direct"])

    return {
        "stage": str(stage),
        "seed": seed,
        "signal_present": True,
        "signal_amplitude": signal_amplitude,
        "slow_centroid_wander_scale": 0.0,
        "additional_broadening_sigma_Hz": 0.0,
        "scintillation_strength": strength,
        "modulation_index": modulation_index,
        "occupancy_above_mean": occupancy_above_mean,
        "mean_scintillation_intensity": mean_intensity,
        # Primary transmitter/carrier power before propagation paths.  This is
        # exactly the quantity fixed by the mean(A^2) normalization.
        "total_injected_signal_power": float(np.mean(np.abs(direct) ** 2)),
        "propagated_component_power": float(truth["injected_component_power"]),
        "coherent_signal_power": float(truth["coherent_signal_power"]),
        "best_score": result.best_score,
        "best_f0": result.best_f0,
        "best_drift_rate": result.best_drift_rate,
        "drift_error": result.best_drift_rate - INJECTED_DRIFT_RATE_HZ_S,
        "n_f0_trials": result.n_f0_trials,
        "n_drift_trials": result.n_drift_trials,
        "n_valid_tracks": result.n_valid_tracks,
    }


def run_tasks(
    tasks: list[tuple[object, ...]], workers: int
) -> tuple[list[dict[str, object]], float]:
    started = time.perf_counter()
    if workers == 1:
        rows = [_worker(task) for task in tasks]
    else:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            rows = list(executor.map(_worker, tasks, chunksize=1))
    return rows, time.perf_counter() - started


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError("cannot write an empty table")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as output_file:
        writer = csv.DictWriter(output_file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def validate_reused_threshold(config: LinearDriftSearchConfig) -> tuple[float, dict[str, object]]:
    metadata = read_json(WANDER_OUTPUT_DIR / "noise_thresholds.json")
    if metadata["search_config"] != asdict(config):
        raise RuntimeError("search grid changed; existing threshold cannot be reused")
    threshold = float(metadata["fixed_threshold"])
    if not math.isclose(threshold, 156666.25361187334, rel_tol=0.0, abs_tol=1e-8):
        raise RuntimeError("stored threshold differs from completed experiments")
    return threshold, metadata


def summarize(rows: list[dict[str, object]], threshold: float) -> list[dict[str, object]]:
    grouped: dict[float, list[dict[str, object]]] = {}
    for row in rows:
        grouped.setdefault(float(row["scintillation_strength"]), []).append(row)

    summaries: list[dict[str, object]] = []
    baseline_power: float | None = None
    for strength in sorted(grouped):
        group = grouped[strength]
        trials = len(group)
        detected = sum(float(row["best_score"]) > threshold for row in group)
        low, high = wilson_interval(detected, trials)
        modulation = np.array([float(row["modulation_index"]) for row in group])
        occupancy = np.array([float(row["occupancy_above_mean"]) for row in group])
        powers = np.array([float(row["total_injected_signal_power"]) for row in group])
        coherent = np.array([float(row["coherent_signal_power"]) for row in group])
        mean_power = float(np.mean(powers))
        if baseline_power is None:
            baseline_power = mean_power
        summaries.append(
            {
                "scintillation_strength": strength,
                "signal_amplitude": float(group[0]["signal_amplitude"]),
                "detected_count": detected,
                "trial_count": trials,
                "detection_probability": detected / trials,
                "wilson_95_low": low,
                "wilson_95_high": high,
                "modulation_index_mean": float(np.mean(modulation)),
                "modulation_index_std": float(np.std(modulation, ddof=1)),
                "occupancy_above_mean_mean": float(np.mean(occupancy)),
                "occupancy_above_mean_std": float(np.std(occupancy, ddof=1)),
                "total_injected_signal_power_mean": mean_power,
                "total_injected_signal_power_relative_to_baseline": mean_power / baseline_power,
                "coherent_signal_power_mean": float(np.mean(coherent)),
                "best_score_mean": float(np.mean([float(row["best_score"]) for row in group])),
                "drift_error_rmse": float(
                    np.sqrt(np.mean([float(row["drift_error"]) ** 2 for row in group]))
                ),
            }
        )
    return summaries


def plot_curve(
    summary: list[dict[str, object]],
    x_key: str,
    xlabel: str,
    path: Path,
    crossings: dict[str, float | None],
) -> None:
    x = np.array([float(row[x_key]) for row in summary])
    p = np.array([float(row["detection_probability"]) for row in summary])
    low = np.array([float(row["wilson_95_low"]) for row in summary])
    high = np.array([float(row["wilson_95_high"]) for row in summary])
    fig, axis = plt.subplots(figsize=(8.8, 5.8))
    axis.errorbar(
        x,
        p,
        yerr=np.vstack((p - low, high - p)),
        fmt="o-",
        color="#059669",
        ecolor="#34d399",
        capsize=4,
        linewidth=1.8,
        label="Scintillation (95% Wilson interval)",
    )
    for target, color in ((0.9, "#d97706"), (0.5, "#dc2626")):
        axis.axhline(target, color=color, linestyle="--", linewidth=1.1, alpha=0.8)
        crossing = crossings[str(target)]
        if crossing is not None:
            axis.axvline(crossing, color=color, linestyle=":", linewidth=1.1, alpha=0.8)
    axis.set_xlabel(xlabel)
    axis.set_ylabel("Detection probability")
    axis.set_ylim(-0.03, 1.03)
    axis.set_title("Blind linear-drift efficiency vs scintillation")
    if float(np.max(x)) > 10.0:
        axis.set_xscale("symlog", linthresh=0.5)
        axis.set_xlim(0.0, float(np.max(x)) * 1.05)
    axis.grid(alpha=0.22)
    axis.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def plot_representative_intensities(
    strengths: list[float], seed: int, path: Path
) -> None:
    fig, axes = plt.subplots(len(strengths), 1, figsize=(11.2, 7.8), sharex=True)
    if len(strengths) == 1:
        axes = [axes]
    for axis, strength in zip(axes, strengths):
        simulation = simulate(
            seed,
            centroid_wander_scale=0.0,
            broadening_sigma_hz=0.0,
            scintillation_strength=strength,
            signal_amplitude=SIGNAL_AMPLITUDE,
            return_truth=True,
        )
        time_axis, _det, _instant, _received, _fs, truth = simulation
        intensity = np.asarray(truth["scintillation_intensity"], dtype=float)
        relative_intensity = intensity / np.mean(intensity)
        modulation = float(np.std(relative_intensity))
        occupancy = (
            1.0
            if modulation < 1e-12
            else float(np.mean(relative_intensity >= 1.0))
        )
        axis.plot(time_axis, relative_intensity, color="#059669", linewidth=0.85)
        axis.axhline(1.0, color="#374151", linestyle="--", linewidth=0.8)
        axis.set_ylabel(r"$I/\langle I\rangle$")
        axis.set_title(
            f"strength={strength:g}, modulation index={modulation:.3f}, "
            f"occupancy(I>=mean)={occupancy:.3f}",
            loc="left",
            fontsize=10,
        )
        axis.grid(alpha=0.18)
    axes[-1].set_xlabel("Time (s)")
    fig.suptitle("Representative normalized scintillation intensity time series")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def make_three_experiment_summary(
    scintillation_summary: list[dict[str, object]],
    modulation_crossings: dict[str, float | None],
    path: Path,
) -> list[dict[str, object]]:
    wander = read_json(WANDER_OUTPUT_DIR / "wander_efficiency_experiment.json")
    broadening = read_json(
        BROADENING_OUTPUT_DIR / "broadening_efficiency_experiment.json"
    )
    rows = [
        {
            "experiment": "centroid_wander",
            "physical_metric": "wander_rms_Hz",
            "baseline_detection_rate": float(wander["summary"][0]["detection_probability"]),
            "crossing_90": wander["wander_rms_Hz_crossings"]["0.9"],
            "crossing_50": wander["wander_rms_Hz_crossings"]["0.5"],
            "minimum_measured_detection_rate": min(
                float(row["detection_probability"]) for row in wander["summary"]
            ),
        },
        {
            "experiment": "spectral_broadening",
            "physical_metric": "effective_width_Hz",
            "baseline_detection_rate": float(
                broadening["summary"][0]["detection_probability"]
            ),
            "crossing_90": broadening["effective_width_Hz_crossings"]["0.9"],
            "crossing_50": broadening["effective_width_Hz_crossings"]["0.5"],
            "minimum_measured_detection_rate": min(
                float(row["detection_probability"]) for row in broadening["summary"]
            ),
        },
        {
            "experiment": "scintillation",
            "physical_metric": "modulation_index_dimensionless",
            "baseline_detection_rate": float(
                scintillation_summary[0]["detection_probability"]
            ),
            "crossing_90": modulation_crossings["0.9"],
            "crossing_50": modulation_crossings["0.5"],
            "minimum_measured_detection_rate": min(
                float(row["detection_probability"])
                for row in scintillation_summary
            ),
        },
    ]
    write_rows(path, rows)
    return rows


def run_stage(args: argparse.Namespace) -> None:
    config = LinearDriftSearchConfig()
    threshold, threshold_metadata = validate_reused_threshold(config)
    strengths = [float(value) for value in args.strengths]
    tasks = [
        (args.stage, args.seed_start + index, strength, SIGNAL_AMPLITUDE, config)
        for strength in strengths
        for index in range(args.runs)
    ]
    rows, elapsed = run_tasks(tasks, args.workers)
    for row in rows:
        row["fixed_threshold"] = threshold
        row["detected"] = float(row["best_score"]) > threshold

    output_dir = args.output_dir
    if args.stage == "pilot":
        write_rows(output_dir / "scintillation_pilot_runs.csv", rows)
        summary = summarize(rows, threshold)
        write_rows(output_dir / "scintillation_pilot_summary.csv", summary)
        payload = {
            "runs_per_condition": args.runs,
            "elapsed_seconds": elapsed,
            "fixed_threshold": threshold,
            "signal_amplitude": SIGNAL_AMPLITUDE,
            "summary": summary,
        }
        write_json(output_dir / "scintillation_pilot.json", payload)
        print(json.dumps(payload, indent=2))
        return

    write_rows(output_dir / "scintillation_sweep_results.csv", rows)
    summary = summarize(rows, threshold)
    write_rows(output_dir / "scintillation_efficiency_summary.csv", summary)

    probabilities = [float(row["detection_probability"]) for row in summary]
    strength_values = [float(row["scintillation_strength"]) for row in summary]
    modulation_values = [float(row["modulation_index_mean"]) for row in summary]
    strength_crossings = {
        str(target): interpolate_downward_crossing(strength_values, probabilities, target)
        for target in (0.9, 0.5)
    }
    modulation_crossings = {
        str(target): interpolate_downward_crossing(modulation_values, probabilities, target)
        for target in (0.9, 0.5)
    }

    plot_curve(
        summary,
        "scintillation_strength",
        "Scintillation strength",
        output_dir / "detection_efficiency_vs_scintillation_strength.png",
        strength_crossings,
    )
    plot_curve(
        summary,
        "modulation_index_mean",
        "Measured intensity modulation index (dimensionless)",
        output_dir / "detection_efficiency_vs_modulation_index.png",
        modulation_crossings,
    )
    representative_strengths = [strengths[0], strengths[len(strengths) // 2], strengths[-1]]
    plot_representative_intensities(
        representative_strengths,
        args.seed_start,
        output_dir / "representative_scintillation_intensity.png",
    )
    comparison = make_three_experiment_summary(
        summary,
        modulation_crossings,
        output_dir / "three_experiment_summary.csv",
    )

    pilot_path = output_dir / "scintillation_pilot.json"
    pilot = read_json(pilot_path) if pilot_path.exists() else {}
    pilot_all_path = output_dir / "scintillation_pilot_all_rounds.json"
    pilot_all = read_json(pilot_all_path) if pilot_all_path.exists() else {}
    pilot_elapsed = float(
        pilot_all.get("total_elapsed_seconds", pilot.get("elapsed_seconds", 0.0))
    )
    powers = np.array(
        [float(row["total_injected_signal_power_mean"]) for row in summary]
    )
    payload = {
        "fixed_threshold": threshold,
        "threshold_source": str(WANDER_OUTPUT_DIR / "noise_thresholds.json"),
        "threshold_noise_runs": threshold_metadata["runs"],
        "signal_amplitude": SIGNAL_AMPLITUDE,
        "slow_centroid_wander_scale": 0.0,
        "additional_broadening_sigma_Hz": 0.0,
        "runs_per_condition": args.runs,
        "wilson_interval_confidence": 0.95,
        "modulation_index_definition": "std(I)/mean(I), I=|A|^2",
        "occupancy_definition": "fraction of time samples with I >= mean(I)",
        "power_normalization": "each strength matches the paired seed's original strength=1 mean(A^2)",
        "injected_power_definition": "mean(|direct|^2), primary carrier before propagation paths",
        "injected_power_relative_span": float((powers.max() - powers.min()) / powers[0]),
        "strength_crossings": strength_crossings,
        "modulation_index_crossings": modulation_crossings,
        "pilot_elapsed_seconds": pilot_elapsed,
        "sweep_elapsed_seconds": elapsed,
        "total_execution_seconds": elapsed + pilot_elapsed,
        "three_experiment_summary": comparison,
        "summary": summary,
    }
    write_json(output_dir / "scintillation_efficiency_experiment.json", payload)
    print(json.dumps(payload, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("pilot", "sweep"))
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument("--runs", type=int)
    parser.add_argument("--seed-start", type=int)
    parser.add_argument(
        "--strengths",
        nargs="+",
        type=float,
        default=[0.0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0],
    )
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    if args.runs is None:
        args.runs = 10 if args.stage == "pilot" else 100
    if args.seed_start is None:
        args.seed_start = 600_000 if args.stage == "pilot" else 700_000
    if args.runs < 1:
        parser.error("--runs must be positive")
    if any(strength < 0.0 for strength in args.strengths):
        parser.error("strengths must be non-negative")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    run_stage(args)


if __name__ == "__main__":
    main()
