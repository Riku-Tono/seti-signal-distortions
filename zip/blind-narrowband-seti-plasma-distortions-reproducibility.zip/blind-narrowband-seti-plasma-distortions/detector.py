"""Blind straight-line drift detector for narrowband dynamic spectra.

The detector receives only an STFT power array and its time/frequency axes.  It
does not accept an injected track, injected drift rate, or plasma realization.
For every trial ``f(t) = f0 + drift_rate * t``, it selects the nearest frequency
bin in each time column and sums the corresponding powers.

Noise normalization is intentionally separate.  Run the identical full search
on independent noise-only realizations, then standardize a best score against
the distribution of noise-only *best* scores.  Using maxima here includes the
look-elsewhere effect from searching many trial tracks.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class LinearDriftSearchConfig:
    """Grid definition for the blind linear-track search."""

    f0_min_hz: float = -24.0
    f0_max_hz: float = 22.0
    f0_step_hz: float = 0.25
    drift_min_hz_s: float = -1.0
    drift_max_hz_s: float = 1.0
    drift_step_hz_s: float = 0.01


@dataclass(frozen=True)
class LinearDriftSearchResult:
    best_score: float
    best_f0: float
    best_drift_rate: float
    n_f0_trials: int
    n_drift_trials: int
    n_valid_tracks: int


@dataclass(frozen=True)
class NoiseNormalization:
    mean: float
    std: float
    sample_count: int


def _inclusive_grid(start: float, stop: float, step: float) -> np.ndarray:
    if step <= 0.0:
        raise ValueError("grid step must be positive")
    if stop < start:
        raise ValueError("grid stop must be >= grid start")
    count = int(np.floor((stop - start) / step + 1e-10)) + 1
    return start + step * np.arange(count, dtype=float)


def search_linear_drift(
    power: np.ndarray,
    times_s: np.ndarray,
    frequencies_hz: np.ndarray,
    config: LinearDriftSearchConfig | None = None,
) -> LinearDriftSearchResult:
    """Search all configured straight tracks and return the largest power sum.

    Parameters contain no injected truth.  ``power`` must have shape
    ``(frequency, time)``. Tracks leaving the supplied frequency axis are
    invalid and are excluded rather than shortened, so every valid score sums
    the same number of time samples.
    """
    if config is None:
        config = LinearDriftSearchConfig()

    power = np.asarray(power, dtype=float)
    times_s = np.asarray(times_s, dtype=float)
    frequencies_hz = np.asarray(frequencies_hz, dtype=float)

    if power.ndim != 2:
        raise ValueError("power must be a 2-D (frequency, time) array")
    if power.shape != (frequencies_hz.size, times_s.size):
        raise ValueError("power shape does not match frequency/time axes")
    if times_s.size == 0 or frequencies_hz.size < 2:
        raise ValueError("time and frequency axes must be non-empty")
    if not np.all(np.diff(frequencies_hz) > 0.0):
        raise ValueError("frequency axis must be strictly increasing")

    bin_widths = np.diff(frequencies_hz)
    frequency_bin_hz = float(np.median(bin_widths))
    if not np.allclose(bin_widths, frequency_bin_hz, rtol=1e-7, atol=1e-10):
        raise ValueError("frequency axis must be uniformly spaced")

    f0_trials = _inclusive_grid(
        config.f0_min_hz, config.f0_max_hz, config.f0_step_hz
    )
    drift_trials = _inclusive_grid(
        config.drift_min_hz_s,
        config.drift_max_hz_s,
        config.drift_step_hz_s,
    )

    # f0 is defined at physical t=0, even though centered STFT timestamps start
    # later.  Map each trial frequency to its nearest observed frequency bin.
    frequency_origin = frequencies_hz[0]
    time_columns = np.arange(times_s.size)
    best_score = -np.inf
    best_f0 = np.nan
    best_drift_rate = np.nan
    valid_track_count = 0

    for drift_rate in drift_trials:
        trial_frequencies = (
            f0_trials[:, None] + drift_rate * times_s[None, :]
        )
        bin_indices = np.rint(
            (trial_frequencies - frequency_origin) / frequency_bin_hz
        ).astype(np.int64)
        valid = np.all(
            (bin_indices >= 0) & (bin_indices < frequencies_hz.size), axis=1
        )
        if not np.any(valid):
            continue

        valid_indices = bin_indices[valid]
        scores = power[valid_indices, time_columns[None, :]].sum(axis=1)
        local_index = int(np.argmax(scores))
        local_score = float(scores[local_index])
        valid_f0 = f0_trials[valid]
        valid_track_count += int(valid_f0.size)

        if local_score > best_score:
            best_score = local_score
            best_f0 = float(valid_f0[local_index])
            best_drift_rate = float(drift_rate)

    if not np.isfinite(best_score):
        raise ValueError("no trial track stays inside the supplied frequency axis")

    return LinearDriftSearchResult(
        best_score=best_score,
        best_f0=best_f0,
        best_drift_rate=best_drift_rate,
        n_f0_trials=int(f0_trials.size),
        n_drift_trials=int(drift_trials.size),
        n_valid_tracks=valid_track_count,
    )


def estimate_noise_normalization(
    noise_only_best_scores: np.ndarray,
) -> NoiseNormalization:
    """Estimate normalization from independent noise-only search maxima."""
    scores = np.asarray(noise_only_best_scores, dtype=float)
    scores = scores[np.isfinite(scores)]
    if scores.size < 2:
        raise ValueError("at least two finite noise-only best scores are required")
    standard_deviation = float(np.std(scores, ddof=1))
    if standard_deviation <= 0.0:
        raise ValueError("noise-only best-score standard deviation must be positive")
    return NoiseNormalization(
        mean=float(np.mean(scores)),
        std=standard_deviation,
        sample_count=int(scores.size),
    )


def normalize_best_score(
    best_score: float, normalization: NoiseNormalization
) -> float:
    """Return (best_score - noise_mean) / noise_std."""
    return (float(best_score) - normalization.mean) / normalization.std
