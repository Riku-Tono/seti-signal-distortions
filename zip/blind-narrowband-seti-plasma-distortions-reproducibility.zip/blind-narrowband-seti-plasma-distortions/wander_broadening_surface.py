"""Measure the 2-D wander x spectral-broadening detection surface.

The blind detector is imported unchanged.  Every detector call receives only
the observed STFT power and its observed axes.  Injected wander, width, and
power are measured after the search and are used only for scoring.

All grid cells use the same seed set.  Thus receiver noise, baseline
scintillation, fast fluctuations, halo, and multipath are paired; only the
slow-centroid multiplier and independent additional phase broadening change.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
from pathlib import Path

import numpy as np

os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "wander-broadening-matplotlib")
)
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

from broadening_efficiency import measure_effective_width_hz
from detector import LinearDriftSearchConfig, search_linear_drift
from plasma_wandering_signal import (
    INJECTED_DRIFT_RATE_HZ_S,
    centroid_wander_truth,
    simulate,
    stft,
)
from wander_efficiency import wilson_interval


ROOT = Path(__file__).parent
DEFAULT_OUTPUT_DIR = ROOT / "wander_broadening_surface_outputs"
WANDER_OUTPUT_DIR = ROOT / "wander_efficiency_outputs"
BROADENING_OUTPUT_DIR = ROOT / "broadening_efficiency_outputs"
FIXED_THRESHOLD = 156666.25361187334
SIGNAL_AMPLITUDE = 0.034
EXPECTED_DETECTOR_SHA256 = (
    "7CD4AC1D032336A246120D3956A87F6929C31412DECA33A9316F3AD29440F68C"
)
DEFAULT_WANDER_SCALES = [0.0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0]
DEFAULT_BROADENING_HZ = [0.0, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5]


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError("cannot write an empty table")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as output_file:
        writer = csv.DictWriter(output_file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as input_file:
        return list(csv.DictReader(input_file))


def validate_fixed_configuration(config: LinearDriftSearchConfig) -> str:
    metadata = read_json(WANDER_OUTPUT_DIR / "noise_thresholds.json")
    if metadata["search_config"] != asdict(config):
        raise RuntimeError("detector grid changed; the frozen threshold is invalid")
    if not math.isclose(
        float(metadata["fixed_threshold"]), FIXED_THRESHOLD, rel_tol=0.0, abs_tol=1e-8
    ):
        raise RuntimeError("stored noise threshold differs from the frozen threshold")
    detector_hash = hashlib.sha256((ROOT / "detector.py").read_bytes()).hexdigest().upper()
    if detector_hash != EXPECTED_DETECTOR_SHA256:
        raise RuntimeError("detector.py changed; refusing to run the 2-D comparison")
    return detector_hash


def _worker(task: tuple[object, ...]) -> dict[str, object]:
    stage, seed, wander_scale, broadening_hz, config = task
    seed = int(seed)
    wander_scale = float(wander_scale)
    broadening_hz = float(broadening_hz)
    assert isinstance(config, LinearDriftSearchConfig)

    simulation = simulate(
        seed,
        centroid_wander_scale=wander_scale,
        signal_present=True,
        signal_amplitude=SIGNAL_AMPLITUDE,
        broadening_sigma_hz=broadening_hz,
        scintillation_strength=1.0,
        return_truth=True,
    )
    time_axis, deterministic_frequency, _instantaneous, received, fs, truth = simulation
    stft_time, frequency, spectrum = stft(received, fs)
    power = np.abs(spectrum) ** 2

    # Blind boundary: no injected track, wander, width, or truth enters here.
    result = search_linear_drift(power, stft_time, frequency, config)

    # Truth-side evaluation starts only after the blind detector returns.
    injected_wander = centroid_wander_truth(seed, wander_scale)
    centered_wander = injected_wander - np.mean(injected_wander)
    wander_rms_hz = float(np.sqrt(np.mean(centered_wander**2)))
    local_centroid_track = deterministic_frequency + injected_wander
    effective_width_hz = measure_effective_width_hz(
        np.asarray(truth["signal_only"]),
        fs,
        time_axis,
        local_centroid_track,
    )

    return {
        "stage": str(stage),
        "seed": seed,
        "signal_amplitude": SIGNAL_AMPLITUDE,
        "scintillation_strength": 1.0,
        "wander_scale": wander_scale,
        "wander_rms_Hz": wander_rms_hz,
        "broadening_scale_Hz": broadening_hz,
        "effective_width_Hz": effective_width_hz,
        "best_score": result.best_score,
        "best_f0": result.best_f0,
        "best_drift_rate": result.best_drift_rate,
        "drift_error": result.best_drift_rate - INJECTED_DRIFT_RATE_HZ_S,
        "total_injected_signal_power": float(truth["injected_component_power"]),
        "coherent_signal_power": float(truth["coherent_signal_power"]),
        "n_f0_trials": result.n_f0_trials,
        "n_drift_trials": result.n_drift_trials,
        "n_valid_tracks": result.n_valid_tracks,
    }


def run_tasks(
    tasks: list[tuple[object, ...]], workers: int
) -> tuple[list[dict[str, object]], float]:
    started = time.perf_counter()
    if workers == 1:
        rows = [_worker(task) for task in tasks]
    else:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            rows = list(executor.map(_worker, tasks, chunksize=1))
    return rows, time.perf_counter() - started


def summarize_cells(
    rows: list[dict[str, object]], threshold: float
) -> list[dict[str, object]]:
    grouped: dict[tuple[float, float], list[dict[str, object]]] = {}
    for row in rows:
        key = (float(row["wander_scale"]), float(row["broadening_scale_Hz"]))
        grouped.setdefault(key, []).append(row)

    summary: list[dict[str, object]] = []
    for (wander_scale, broadening_hz), group in sorted(grouped.items()):
        detected = sum(bool(row["detected"]) for row in group)
        trials = len(group)
        low, high = wilson_interval(detected, trials)
        wander_values = np.array([float(row["wander_rms_Hz"]) for row in group])
        width_values = np.array([float(row["effective_width_Hz"]) for row in group])
        power_values = np.array(
            [float(row["total_injected_signal_power"]) for row in group]
        )
        summary.append(
            {
                "wander_scale": wander_scale,
                "broadening_scale_Hz": broadening_hz,
                "wander_rms_Hz_mean": float(np.mean(wander_values)),
                "wander_rms_Hz_std": float(np.std(wander_values, ddof=1)),
                "effective_width_Hz_mean": float(np.mean(width_values)),
                "effective_width_Hz_std": float(np.std(width_values, ddof=1)),
                "detected_count": detected,
                "n_trials": trials,
                "P_detect": detected / trials,
                "wilson_95_low": low,
                "wilson_95_high": high,
                "best_score_mean": float(
                    np.mean([float(row["best_score"]) for row in group])
                ),
                "drift_error_rmse": float(
                    np.sqrt(
                        np.mean([float(row["drift_error"]) ** 2 for row in group])
                    )
                ),
                "total_injected_signal_power_mean": float(np.mean(power_values)),
                "total_injected_signal_power_std": float(np.std(power_values, ddof=1)),
            }
        )
    return summary


def add_interaction_reference(
    rows: list[dict[str, object]],
    summary: list[dict[str, object]],
    bootstrap_repetitions: int,
    bootstrap_seed: int,
) -> None:
    """Add a paired-axis independence reference and paired bootstrap CI.

    P_w and P_b are the newly replicated single-effect axis cells.  These axes
    use the same paired seed set as each combined cell and are separately
    checked against the completed historical 1-D response curves.
    """
    row_lookup = {
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"]), int(row["seed"])):
        float(row["best_score"]) > FIXED_THRESHOLD
        for row in rows
    }
    summary_lookup = {
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"])): row
        for row in summary
    }
    rng = np.random.default_rng(bootstrap_seed)
    for (wander_scale, broadening_hz), cell in summary_lookup.items():
        keys = (
            (wander_scale, broadening_hz),
            (wander_scale, 0.0),
            (0.0, broadening_hz),
            (0.0, 0.0),
        )
        seed_sets = [
            {
                seed
                for (row_wander, row_broadening, seed) in row_lookup
                if row_wander == key[0] and row_broadening == key[1]
            }
            for key in keys
        ]
        seeds = sorted(set.intersection(*seed_sets))
        if not seeds:
            raise RuntimeError(f"no paired seeds available for cell {keys[0]}")
        cell_values = np.array(
            [row_lookup[(wander_scale, broadening_hz, seed)] for seed in seeds], dtype=float
        )
        wander_values = np.array(
            [row_lookup[(wander_scale, 0.0, seed)] for seed in seeds], dtype=float
        )
        broadening_values = np.array(
            [row_lookup[(0.0, broadening_hz, seed)] for seed in seeds], dtype=float
        )
        baseline_values = np.array(
            [row_lookup[(0.0, 0.0, seed)] for seed in seeds], dtype=float
        )
        observed = float(np.mean(cell_values))
        pw = float(np.mean(wander_values))
        pb = float(np.mean(broadening_values))
        p0 = float(np.mean(baseline_values))
        if p0 <= 0.0:
            raise RuntimeError("zero paired baseline efficiency prevents reference")
        expected = pw * pb / p0
        residual = observed - expected

        samples = rng.integers(
            0, len(seeds), size=(bootstrap_repetitions, len(seeds))
        )
        boot_observed = cell_values[samples].mean(axis=1)
        boot_pw = wander_values[samples].mean(axis=1)
        boot_pb = broadening_values[samples].mean(axis=1)
        boot_p0 = baseline_values[samples].mean(axis=1)
        valid = boot_p0 > 0.0
        boot_residual = (
            boot_observed[valid] - boot_pw[valid] * boot_pb[valid] / boot_p0[valid]
        )
        lower, upper = np.quantile(boot_residual, [0.025, 0.975])

        cell.update(
            {
                "P_w_axis": pw,
                "P_b_axis": pb,
                "P0_axis": p0,
                "interaction_paired_n": len(seeds),
                "P_expected_independent": expected,
                "interaction_residual": residual,
                "interaction_bootstrap_95_low": float(lower),
                "interaction_bootstrap_95_high": float(upper),
                "interaction_ci_excludes_zero": bool(lower > 0.0 or upper < 0.0),
            }
        )


def compare_historical_axes(
    summary: list[dict[str, object]],
) -> list[dict[str, object]]:
    wander_history = {
        float(row["wander_scale"]): row
        for row in read_rows(WANDER_OUTPUT_DIR / "wander_efficiency_summary.csv")
    }
    broadening_history = {
        float(row["broadening_scale"]): row
        for row in read_rows(
            BROADENING_OUTPUT_DIR / "broadening_efficiency_summary.csv"
        )
    }
    lookup = {
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"])): row
        for row in summary
    }
    comparisons: list[dict[str, object]] = []
    for scale, old in sorted(wander_history.items()):
        if (scale, 0.0) not in lookup:
            continue
        new = lookup[(scale, 0.0)]
        comparisons.append(
            axis_comparison("wander", scale, float(old["detection_probability"]), int(old["trial_count"]), new)
        )
    for scale, old in sorted(broadening_history.items()):
        if (0.0, scale) not in lookup:
            continue
        new = lookup[(0.0, scale)]
        comparisons.append(
            axis_comparison("broadening", scale, float(old["detection_probability"]), int(old["trial_count"]), new)
        )
    return comparisons


def axis_comparison(
    axis: str,
    scale: float,
    historical_p: float,
    historical_n: int,
    current: dict[str, object],
) -> dict[str, object]:
    current_p = float(current["P_detect"])
    current_n = int(current["n_trials"])
    standard_error = math.sqrt(
        historical_p * (1.0 - historical_p) / historical_n
        + current_p * (1.0 - current_p) / current_n
    )
    z = (current_p - historical_p) / standard_error if standard_error else 0.0
    return {
        "axis": axis,
        "scale": scale,
        "historical_P_detect": historical_p,
        "current_P_detect": current_p,
        "difference": current_p - historical_p,
        "independent_two_sample_z": z,
        "consistent_within_95_percent_sampling": abs(z) <= 1.959963984540054,
    }


def grid_arrays(
    summary: list[dict[str, object]],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, list[float], list[float]]:
    wander_scales = sorted({float(row["wander_scale"]) for row in summary})
    broadening_scales = sorted(
        {float(row["broadening_scale_Hz"]) for row in summary}
    )
    lookup = {
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"])): row
        for row in summary
    }
    shape = (len(wander_scales), len(broadening_scales))
    x_width = np.empty(shape)
    y_wander = np.empty(shape)
    probability = np.empty(shape)
    residual = np.empty(shape)
    expected = np.empty(shape)
    for i, wander_scale in enumerate(wander_scales):
        for j, broadening_scale in enumerate(broadening_scales):
            row = lookup[(wander_scale, broadening_scale)]
            x_width[i, j] = float(row["effective_width_Hz_mean"])
            y_wander[i, j] = float(row["wander_rms_Hz_mean"])
            probability[i, j] = float(row["P_detect"])
            residual[i, j] = float(row["interaction_residual"])
            expected[i, j] = float(row["P_expected_independent"])
    return (
        x_width,
        y_wander,
        probability,
        residual,
        expected,
        wander_scales,
        broadening_scales,
    )


def plot_probability_heatmap(
    x: np.ndarray,
    y: np.ndarray,
    probability: np.ndarray,
    path: Path,
    *,
    add_contours: bool,
) -> list[dict[str, object]]:
    fig, axis = plt.subplots(figsize=(10.0, 7.1))
    image = axis.pcolormesh(
        x, y, probability, shading="nearest", cmap="viridis", vmin=0.0, vmax=1.0
    )
    colorbar = fig.colorbar(image, ax=axis)
    colorbar.set_label("Detection probability")
    contour_rows: list[dict[str, object]] = []
    if add_contours:
        contours = axis.contour(
            x,
            y,
            probability,
            levels=[0.5, 0.9],
            colors=["#ef4444", "#f59e0b"],
            linewidths=2.0,
        )
        axis.clabel(contours, inline=True, fmt={0.5: "50%", 0.9: "90%"})
        for level, segments in zip(contours.levels, contours.allsegs):
            for segment_index, segment in enumerate(segments):
                for vertex_index, (width_hz, wander_hz) in enumerate(segment):
                    contour_rows.append(
                        {
                            "P_detect_level": float(level),
                            "segment": segment_index,
                            "vertex": vertex_index,
                            "effective_width_Hz": float(width_hz),
                            "wander_rms_Hz": float(wander_hz),
                        }
                    )
    axis.set_xlabel("Mean effective spectral width (Hz)")
    axis.set_ylabel("Mean slow-centroid wander RMS (Hz)")
    axis.set_title(
        "Blind linear-drift detection surface"
        + (" with grid-interpolated contours" if add_contours else "")
    )
    axis.grid(alpha=0.18)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)
    return contour_rows


def plot_interaction_heatmap(
    x: np.ndarray, y: np.ndarray, residual: np.ndarray, path: Path
) -> None:
    limit = max(float(np.max(np.abs(residual))), 0.01)
    fig, axis = plt.subplots(figsize=(10.0, 7.1))
    image = axis.pcolormesh(
        x,
        y,
        residual,
        shading="nearest",
        cmap="RdBu_r",
        norm=TwoSlopeNorm(vmin=-limit, vcenter=0.0, vmax=limit),
    )
    colorbar = fig.colorbar(image, ax=axis)
    colorbar.set_label(r"Interaction residual $P_{obs}-P_{expected}$")
    axis.set_xlabel("Mean effective spectral width (Hz)")
    axis.set_ylabel("Mean slow-centroid wander RMS (Hz)")
    axis.set_title("Interaction relative to paired-axis independence reference")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def write_probability_table(
    path: Path,
    summary: list[dict[str, object]],
    wander_scales: list[float],
    broadening_scales: list[float],
) -> None:
    lookup = {
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"])):
        float(row["P_detect"])
        for row in summary
    }
    rows: list[dict[str, object]] = []
    for wander_scale in wander_scales:
        row: dict[str, object] = {"wander_scale": wander_scale}
        for broadening_scale in broadening_scales:
            row[f"broadening_{broadening_scale:g}_Hz"] = lookup[
                (wander_scale, broadening_scale)
            ]
        rows.append(row)
    write_rows(path, rows)


def select_representative_failure(
    rows: list[dict[str, object]], summary: list[dict[str, object]]
) -> dict[str, object]:
    interior = [
        row
        for row in summary
        if float(row["wander_scale"]) > 0.0
        and float(row["broadening_scale_Hz"]) > 0.0
        and float(row["P_w_axis"]) >= 0.70
        and float(row["P_b_axis"]) >= 0.70
    ]
    candidates = interior or [
        row
        for row in summary
        if float(row["wander_scale"]) > 0.0
        and float(row["broadening_scale_Hz"]) > 0.0
    ]
    chosen = max(
        candidates,
        key=lambda row: min(float(row["P_w_axis"]), float(row["P_b_axis"]))
        - float(row["P_detect"]),
    )
    wander_scale = float(chosen["wander_scale"])
    broadening_scale = float(chosen["broadening_scale_Hz"])
    by_key = {
        (float(row["wander_scale"]), float(row["broadening_scale_Hz"]), int(row["seed"])):
        bool(row["detected"])
        for row in rows
    }
    seed_sets = []
    for cell_wander, cell_broadening in (
        (wander_scale, 0.0),
        (0.0, broadening_scale),
        (wander_scale, broadening_scale),
    ):
        seed_sets.append(
            {
                int(row["seed"])
                for row in rows
                if float(row["wander_scale"]) == cell_wander
                and float(row["broadening_scale_Hz"]) == cell_broadening
            }
        )
    seeds = sorted(set.intersection(*seed_sets))
    preferred = [
        seed
        for seed in seeds
        if by_key[(wander_scale, 0.0, seed)]
        and by_key[(0.0, broadening_scale, seed)]
        and not by_key[(wander_scale, broadening_scale, seed)]
    ]
    if not preferred:
        preferred = [
            seed
            for seed in seeds
            if not by_key[(wander_scale, broadening_scale, seed)]
        ]
    seed = preferred[0] if preferred else seeds[0]
    return {
        "seed": seed,
        "wander_scale": wander_scale,
        "broadening_scale_Hz": broadening_scale,
        "P_w_axis": float(chosen["P_w_axis"]),
        "P_b_axis": float(chosen["P_b_axis"]),
        "P_combined": float(chosen["P_detect"]),
        "axis_wander_detected_for_seed": by_key[(wander_scale, 0.0, seed)],
        "axis_broadening_detected_for_seed": by_key[(0.0, broadening_scale, seed)],
        "combined_detected_for_seed": by_key[(wander_scale, broadening_scale, seed)],
    }


def plot_representative_spectrograms(
    selection: dict[str, object], config: LinearDriftSearchConfig, path: Path
) -> None:
    seed = int(selection["seed"])
    wander_scale = float(selection["wander_scale"])
    broadening_scale = float(selection["broadening_scale_Hz"])
    conditions = [
        ("Wander only", wander_scale, 0.0),
        ("Broadening only", 0.0, broadening_scale),
        ("Wander + broadening", wander_scale, broadening_scale),
    ]
    panels: list[tuple[str, float, float, np.ndarray, np.ndarray, np.ndarray, object]] = []
    all_db: list[np.ndarray] = []
    for label, wander, broadening in conditions:
        simulation = simulate(
            seed,
            centroid_wander_scale=wander,
            signal_present=True,
            signal_amplitude=SIGNAL_AMPLITUDE,
            broadening_sigma_hz=broadening,
            scintillation_strength=1.0,
        )
        _time, _track, _instant, received, fs = simulation
        stft_time, frequency, spectrum = stft(received, fs)
        power = np.abs(spectrum) ** 2
        result = search_linear_drift(power, stft_time, frequency, config)
        frequency_mask = (frequency >= -25.0) & (frequency <= 22.0)
        db = 10.0 * np.log10(power[frequency_mask] + np.finfo(float).tiny)
        panels.append(
            (
                label,
                wander,
                broadening,
                stft_time,
                frequency[frequency_mask],
                db,
                result,
            )
        )
        all_db.append(db)
    pooled = np.concatenate([values.ravel() for values in all_db])
    vmin, vmax = np.quantile(pooled, [0.03, 0.997])

    fig, axes = plt.subplots(3, 1, figsize=(13.0, 10.8), sharex=True, sharey=True)
    image = None
    for axis, panel in zip(axes, panels):
        label, wander, broadening, stft_time, frequency, db, result = panel
        image = axis.imshow(
            db,
            origin="lower",
            aspect="auto",
            extent=[stft_time[0], stft_time[-1], frequency[0], frequency[-1]],
            cmap="magma",
            vmin=vmin,
            vmax=vmax,
        )
        best_track = result.best_f0 + result.best_drift_rate * stft_time
        axis.plot(stft_time, best_track, color="#67e8f9", linewidth=1.2, linestyle="--")
        detected = result.best_score > FIXED_THRESHOLD
        axis.set_title(
            f"{label}: wander={wander:g}, broadening={broadening:g} Hz, "
            f"score={result.best_score:.0f}, detected={detected}"
        )
        axis.set_ylabel("Frequency (Hz)")
    axes[-1].set_xlabel("Time (s)")
    fig.subplots_adjust(left=0.08, right=0.86, bottom=0.06, top=0.95, hspace=0.24)
    if image is not None:
        colorbar_axis = fig.add_axes([0.885, 0.12, 0.022, 0.76])
        colorbar = fig.colorbar(image, cax=colorbar_axis)
        colorbar.set_label("STFT power (dB, common scale)")
    fig.suptitle(f"Paired spectrogram comparison, seed={seed}", y=0.995)
    fig.savefig(path, dpi=180)
    plt.close(fig)


def run_stage(args: argparse.Namespace) -> None:
    config = LinearDriftSearchConfig()
    detector_hash = validate_fixed_configuration(config)
    wander_scales = [float(value) for value in args.wander_scales]
    broadening_scales = [float(value) for value in args.broadening_scales]
    tasks = [
        (
            args.stage,
            args.seed_start + index,
            wander_scale,
            broadening_scale,
            config,
        )
        for wander_scale in wander_scales
        for broadening_scale in broadening_scales
        for index in range(args.runs)
    ]
    rows, elapsed = run_tasks(tasks, args.workers)
    for row in rows:
        row["fixed_threshold"] = FIXED_THRESHOLD
        row["detected"] = float(row["best_score"]) > FIXED_THRESHOLD

    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.stage == "pilot":
        write_rows(args.output_dir / "surface_pilot_runs.csv", rows)
        summary = summarize_cells(rows, FIXED_THRESHOLD)
        write_rows(args.output_dir / "surface_pilot_summary.csv", summary)
        payload = {
            "grid_shape": [len(wander_scales), len(broadening_scales)],
            "runs_per_cell": args.runs,
            "total_runs": len(rows),
            "elapsed_seconds": elapsed,
            "projected_100_seed_seconds": elapsed * 100.0 / args.runs,
            "detector_sha256": detector_hash,
            "fixed_threshold": FIXED_THRESHOLD,
            "signal_amplitude": SIGNAL_AMPLITUDE,
        }
        write_json(args.output_dir / "surface_pilot.json", payload)
        print(json.dumps(payload, indent=2))
        return

    add_interaction_reference(
        rows,
        summary := summarize_cells(rows, FIXED_THRESHOLD),
        args.bootstrap_repetitions,
        args.bootstrap_seed,
    )
    write_rows(args.output_dir / "wander_broadening_runs.csv", rows)
    write_rows(args.output_dir / "wander_broadening_cell_summary.csv", summary)
    axis_comparisons = compare_historical_axes(summary)
    write_rows(args.output_dir / "axis_reproduction.csv", axis_comparisons)

    (
        x_width,
        y_wander,
        probability,
        residual,
        _expected,
        sorted_wander,
        sorted_broadening,
    ) = grid_arrays(summary)
    write_probability_table(
        args.output_dir / "detection_probability_table.csv",
        summary,
        sorted_wander,
        sorted_broadening,
    )
    plot_probability_heatmap(
        x_width,
        y_wander,
        probability,
        args.output_dir / "detection_probability_heatmap.png",
        add_contours=False,
    )
    contour_rows = plot_probability_heatmap(
        x_width,
        y_wander,
        probability,
        args.output_dir / "detection_probability_heatmap_with_contours.png",
        add_contours=True,
    )
    if contour_rows:
        write_rows(args.output_dir / "detection_contour_vertices.csv", contour_rows)
    plot_interaction_heatmap(
        x_width,
        y_wander,
        residual,
        args.output_dir / "interaction_residual_heatmap.png",
    )
    selection = select_representative_failure(rows, summary)
    plot_representative_spectrograms(
        selection,
        config,
        args.output_dir / "representative_paired_spectrograms.png",
    )
    write_json(args.output_dir / "representative_cell.json", selection)

    interior = [
        row
        for row in summary
        if float(row["wander_scale"]) > 0.0
        and float(row["broadening_scale_Hz"]) > 0.0
    ]
    most_negative = min(interior, key=lambda row: float(row["interaction_residual"]))
    most_positive = max(interior, key=lambda row: float(row["interaction_residual"]))
    power_means = np.array(
        [float(row["total_injected_signal_power_mean"]) for row in summary]
    )
    by_seed: dict[int, list[float]] = {}
    for row in rows:
        by_seed.setdefault(int(row["seed"]), []).append(
            float(row["total_injected_signal_power"])
        )
    maximum_paired_power_span = max(
        (max(values) - min(values)) / np.mean(values) for values in by_seed.values()
    )
    pilot_path = args.output_dir / "surface_pilot.json"
    pilot = read_json(pilot_path) if pilot_path.exists() else {}
    payload = {
        "grid_shape": [len(sorted_wander), len(sorted_broadening)],
        "runs_per_cell": args.runs,
        "total_runs": len(rows),
        "sampling_design": "full grid, identical paired seed set in every cell",
        "fixed_threshold": FIXED_THRESHOLD,
        "signal_amplitude": SIGNAL_AMPLITUDE,
        "scintillation_strength": 1.0,
        "detector_sha256": detector_hash,
        "search_config": asdict(config),
        "bootstrap_repetitions": args.bootstrap_repetitions,
        "bootstrap_method": "resample paired seed indices jointly for cell, both axis cells, and baseline; percentile 95% CI",
        "independence_reference": "P_expected=P_w_axis*P_b_axis/P0_axis using paired single-effect axes replicated in this grid",
        "contour_interpolation": "Matplotlib linear contour interpolation inside the measured curvilinear grid; no extrapolation",
        "effective_width_definition": "clean-signal STFT power-weighted RMS about deterministic plus injected slow-centroid track, +/-4 Hz",
        "injected_power_definition": "mean(|direct|^2 + |halo|^2 + |delayed|^2)",
        "cell_mean_power_relative_span": float(
            (power_means.max() - power_means.min()) / power_means.mean()
        ),
        "maximum_per_seed_power_relative_span": float(maximum_paired_power_span),
        "axis_reproduction_all_within_95_percent_sampling": all(
            bool(row["consistent_within_95_percent_sampling"])
            for row in axis_comparisons
        ),
        "axis_reproduction_max_absolute_probability_difference": max(
            abs(float(row["difference"])) for row in axis_comparisons
        ),
        "most_negative_interaction": most_negative,
        "most_positive_interaction": most_positive,
        "representative_cell": selection,
        "pilot_elapsed_seconds": pilot.get("elapsed_seconds"),
        "sweep_elapsed_seconds": elapsed,
        "total_execution_seconds": elapsed + float(pilot.get("elapsed_seconds", 0.0)),
    }
    write_json(args.output_dir / "wander_broadening_experiment.json", payload)
    print(json.dumps(payload, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("pilot", "sweep"))
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument("--runs", type=int)
    parser.add_argument("--seed-start", type=int)
    parser.add_argument(
        "--wander-scales", nargs="+", type=float, default=DEFAULT_WANDER_SCALES
    )
    parser.add_argument(
        "--broadening-scales", nargs="+", type=float, default=DEFAULT_BROADENING_HZ
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=5000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260824)
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    if args.runs is None:
        args.runs = 2 if args.stage == "pilot" else 100
    if args.seed_start is None:
        args.seed_start = 800_000 if args.stage == "pilot" else 900_000
    if args.runs < 1:
        parser.error("--runs must be positive")
    if any(value < 0.0 for value in args.wander_scales):
        parser.error("wander scales must be non-negative")
    if any(value < 0.0 for value in args.broadening_scales):
        parser.error("broadening scales must be non-negative")
    if args.bootstrap_repetitions < 100:
        parser.error("bootstrap repetitions must be at least 100")
    run_stage(args)


if __name__ == "__main__":
    main()
