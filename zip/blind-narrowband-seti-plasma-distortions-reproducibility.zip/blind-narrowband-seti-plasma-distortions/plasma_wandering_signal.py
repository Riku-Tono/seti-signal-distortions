"""Generate a synthetic SETI-like waterfall with time-varying plasma effects.

This is a phenomenological complex-baseband simulation, not a turboSETI
pipeline. The signal contains a deterministic Doppler drift plus correlated
frequency wander, scintillation, weak multipath, and receiver noise.

The original three-panel diagnostic workflow is retained.  The optional
``centroid_wander_scale`` and ``signal_present`` arguments are used by the blind
detector sanity check; their defaults reproduce the original simulation.
"""

from __future__ import annotations

import argparse
import os
import tempfile
from pathlib import Path

import numpy as np

os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "plasma-waterfall-matplotlib")
)
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


INJECTED_DRIFT_RATE_HZ_S = 0.28


def ou_process(
    rng: np.random.Generator,
    size: int,
    fs: float,
    correlation_time: float,
    rms: float = 1.0,
) -> np.ndarray:
    """Return a stationary Ornstein-Uhlenbeck process with the requested RMS."""
    alpha = np.exp(-1.0 / (fs * correlation_time))
    drive = rms * np.sqrt(1.0 - alpha * alpha)
    values = np.empty(size, dtype=float)
    values[0] = rng.normal(scale=rms)
    for i in range(1, size):
        values[i] = alpha * values[i - 1] + drive * rng.normal()
    return values


def stft(
    signal: np.ndarray,
    fs: float,
    window_size: int = 1024,
    hop_size: int = 64,
    nfft: int = 2048,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Small NumPy-only two-sided STFT for a complex baseband signal."""
    starts = np.arange(0, signal.size - window_size + 1, hop_size)
    window = np.hanning(window_size)
    frames = np.stack([signal[i : i + window_size] for i in starts])
    spectrum = np.fft.fft(frames * window, n=nfft, axis=1)
    spectrum = np.fft.fftshift(spectrum, axes=1)
    frequencies = np.fft.fftshift(np.fft.fftfreq(nfft, d=1.0 / fs))
    times = (starts + window_size / 2) / fs
    return times, frequencies, spectrum.T


def simulate(
    seed: int = 7,
    *,
    centroid_wander_scale: float = 1.0,
    signal_present: bool = True,
    signal_amplitude: float = 1.0,
    broadening_sigma_hz: float = 0.0,
    scintillation_strength: float = 1.0,
    return_truth: bool = False,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float] | tuple[
    np.ndarray, np.ndarray, np.ndarray, np.ndarray, float, dict[str, object]
]:
    """Simulate received voltage and return hidden truth for later scoring only.

    ``centroid_wander_scale=0`` removes only the slow centroid wandering
    (slow OU component plus plasma wave).  The faster component, scintillation,
    scattering halo, multipath, and receiver noise remain unchanged, ensuring
    the sanity check changes only one factor.
    """
    if signal_amplitude < 0.0:
        raise ValueError("signal_amplitude must be non-negative")
    if broadening_sigma_hz < 0.0:
        raise ValueError("broadening_sigma_hz must be non-negative")
    if scintillation_strength < 0.0:
        raise ValueError("scintillation_strength must be non-negative")

    rng = np.random.default_rng(seed)

    fs = 256.0
    duration = 120.0
    sample_count = int(fs * duration)
    time = np.arange(sample_count) / fs

    drift_rate = INJECTED_DRIFT_RATE_HZ_S
    deterministic_frequency = -18.0 + drift_rate * time

    centroid_wander = make_centroid_wander(
        rng, time, fs, centroid_wander_scale
    )

    # Retained at the same strength in both sanity-check signal conditions.
    # It represents the faster fluctuations/soft broadening baseline, not the
    # slow centroid-wander factor varied in the first experiment.
    fast_wander = ou_process(rng, sample_count, fs, 0.22, rms=0.18)

    # Extra width-only phase modulation.  Its independent RNG stream leaves
    # the original scintillation, halo, multipath, and receiver-noise draws
    # bit-for-bit unchanged.  The realization is centered and normalized so it
    # has zero mean and exactly the requested RMS instantaneous-frequency
    # deviation.  Phase modulation changes no time-domain signal amplitude.
    if broadening_sigma_hz == 0.0:
        extra_broadening_frequency = np.zeros(sample_count)
    else:
        broadening_rng = np.random.default_rng(
            np.random.SeedSequence([seed, 0x42524F41])
        )
        unit_broadening = ou_process(
            broadening_rng, sample_count, fs, 0.06, rms=1.0
        )
        unit_broadening -= np.mean(unit_broadening)
        unit_broadening /= np.sqrt(np.mean(unit_broadening**2))
        extra_broadening_frequency = broadening_sigma_hz * unit_broadening
    instantaneous_frequency = (
        deterministic_frequency
        + centroid_wander
        + fast_wander
        + extra_broadening_frequency
    )

    phase = 2.0 * np.pi * np.cumsum(instantaneous_frequency) / fs

    log_amplitude = ou_process(rng, sample_count, fs, 3.2, rms=0.62)
    reference_amplitude = np.exp(log_amplitude - 0.5 * 0.62**2)
    reference_amplitude = np.clip(reference_amplitude, 0.12, 3.2)
    reference_mean_intensity = float(np.mean(reference_amplitude**2))

    if scintillation_strength == 1.0:
        # Preserve the original model bit-for-bit at the default setting.
        amplitude = reference_amplitude
    else:
        # A_s(t) is proportional to A_1(t)^s.  This preserves the original
        # clipped lognormal shape at s=1, gives a constant at s=0, and increases
        # temporal concentration monotonically without re-clipping artifacts.
        log_shape = scintillation_strength * np.log(reference_amplitude)
        log_shape -= np.max(log_shape)
        amplitude = np.exp(log_shape)
        amplitude *= np.sqrt(reference_mean_intensity / np.mean(amplitude**2))
    direct = signal_amplitude * amplitude * np.exp(1j * phase)

    modulation = (
        ou_process(rng, sample_count, fs, 0.16, rms=1.0)
        + 1j * ou_process(rng, sample_count, fs, 0.16, rms=1.0)
    ) / np.sqrt(2.0)
    scattered_halo = 0.23 * direct * modulation

    delay_samples = int(round(0.086 * fs))
    path_phase = 1.2 * ou_process(rng, sample_count, fs, 2.0, rms=1.0)
    delayed = np.zeros(sample_count, dtype=complex)
    delayed[delay_samples:] = 0.28 * direct[:-delay_samples] * np.exp(
        1j * path_phase[delay_samples:]
    )

    receiver_noise = 0.72 * (
        rng.normal(size=sample_count) + 1j * rng.normal(size=sample_count)
    ) / np.sqrt(2.0)
    signal_only = direct + scattered_halo + delayed
    received = signal_only + receiver_noise
    if not signal_present:
        received = receiver_noise

    result = (time, deterministic_frequency, instantaneous_frequency, received, fs)
    if not return_truth:
        return result

    # The component-power sum excludes coherent cross terms between propagation
    # paths and is the conserved injected-power accounting used by the width
    # experiment.  Each component magnitude is independent of phase broadening.
    component_power = float(
        np.mean(
            np.abs(direct) ** 2
            + np.abs(scattered_halo) ** 2
            + np.abs(delayed) ** 2
        )
    )
    truth: dict[str, object] = {
        "signal_only": signal_only,
        "direct": direct,
        "scattered_halo": scattered_halo,
        "delayed": delayed,
        "extra_broadening_frequency_hz": extra_broadening_frequency,
        "injected_component_power": component_power,
        "coherent_signal_power": float(np.mean(np.abs(signal_only) ** 2)),
        "scintillation_amplitude": amplitude,
        "scintillation_intensity": amplitude**2,
        "scintillation_reference_mean_intensity": reference_mean_intensity,
    }
    return (*result, truth)


def make_centroid_wander(
    rng: np.random.Generator,
    time: np.ndarray,
    fs: float,
    scale: float,
) -> np.ndarray:
    """Generate the slow centroid-wander component varied by the sweep."""
    slow_wander = ou_process(rng, time.size, fs, 4.5, rms=0.34)
    plasma_wave = 0.62 * np.sin(
        2.0 * np.pi * time / 19.0 + 0.45 * np.sin(2.0 * np.pi * time / 51.0)
    )
    return scale * (slow_wander + plasma_wave)


def centroid_wander_truth(seed: int, scale: float) -> np.ndarray:
    """Recreate injected slow wander for post-search evaluation only.

    This function is intentionally separate from detector.py.  It is used only
    after a blind search has returned, to attach the physical wander RMS to an
    experimental row.
    """
    fs = 256.0
    duration = 120.0
    sample_count = int(fs * duration)
    time = np.arange(sample_count) / fs
    rng = np.random.default_rng(seed)
    return make_centroid_wander(rng, time, fs, scale)


def measure_diagnostics(
    power: np.ndarray,
    frequency: np.ndarray,
    expected_track: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Measure peak displacement and noise-debiased local spectral width.

    This truth-assisted function belongs only to the retained diagnostic plot.
    It is not imported or used by detector.py or the detection sanity check.
    """
    observed_peak = np.empty(expected_track.size)
    spectral_width = np.empty(expected_track.size)

    for column, expected_frequency in enumerate(expected_track):
        search = np.abs(frequency - expected_frequency) <= 4.0
        local_frequency = frequency[search]
        local_power = power[search, column]
        peak_frequency = local_frequency[np.argmax(local_power)]
        observed_peak[column] = peak_frequency

        distance = np.abs(frequency - peak_frequency)
        measure = distance <= 2.5
        noise_band = (distance >= 3.5) & (distance <= 6.0)
        noise_floor = np.median(power[noise_band, column])
        weights = np.clip(power[measure, column] - noise_floor, 0.0, None)
        local_frequency = frequency[measure]

        if weights.sum() <= 0.0:
            spectral_width[column] = np.nan
            continue

        centroid = np.sum(weights * local_frequency) / np.sum(weights)
        variance = np.sum(weights * (local_frequency - centroid) ** 2) / np.sum(weights)
        spectral_width[column] = np.sqrt(max(float(variance), 0.0))

    frequency_offset = observed_peak - expected_track
    return frequency_offset, spectral_width


def make_figure(output_path: Path, seed: int = 7, show_tracks: bool = True) -> None:
    """Retained original three-panel diagnostic figure and CSV workflow."""
    time, doppler_frequency, _plasma_frequency, received, fs = simulate(seed)
    stft_time, frequency, spectrum = stft(received, fs)

    power = np.abs(spectrum) ** 2
    noise_reference = np.median(power)
    power_db = 10.0 * np.log10(np.maximum(power / noise_reference, 1e-12))

    visible = (frequency >= -24.0) & (frequency <= 22.0)
    displayed = power_db[visible]
    vmax = float(np.percentile(displayed, 99.85))
    vmin = max(-2.0, vmax - 28.0)

    true_doppler_at_stft = np.interp(stft_time, time, doppler_frequency)
    delta_frequency, spectral_width = measure_diagnostics(
        power, frequency, true_doppler_at_stft
    )
    observed_peak = true_doppler_at_stft + delta_frequency

    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.titlesize": 15,
            "axes.labelsize": 12,
            "figure.facecolor": "#10131a",
            "axes.facecolor": "#090b10",
            "axes.edgecolor": "#aab2c0",
            "axes.labelcolor": "#e6e9ef",
            "xtick.color": "#c8ced8",
            "ytick.color": "#c8ced8",
            "text.color": "#e6e9ef",
        }
    )

    fig = plt.figure(figsize=(12.8, 10.0), constrained_layout=True)
    grid = fig.add_gridspec(
        3, 2, width_ratios=(1.0, 0.035), height_ratios=(3.25, 1.0, 1.0)
    )
    waterfall_ax = fig.add_subplot(grid[0, 0])
    colorbar_ax = fig.add_subplot(grid[0, 1])
    delta_ax = fig.add_subplot(grid[1, 0], sharex=waterfall_ax)
    width_ax = fig.add_subplot(grid[2, 0], sharex=waterfall_ax)

    waterfall_image = waterfall_ax.imshow(
        displayed,
        origin="lower",
        aspect="auto",
        extent=[stft_time[0], stft_time[-1], frequency[visible][0], frequency[visible][-1]],
        cmap="magma",
        interpolation="nearest",
        vmin=vmin,
        vmax=vmax,
    )

    if show_tracks:
        waterfall_ax.plot(
            stft_time,
            true_doppler_at_stft,
            color="#ffffff",
            alpha=0.92,
            linewidth=1.25,
            linestyle=(0, (5, 4)),
            label="true Doppler track (before plasma)",
            zorder=4,
        )
        waterfall_ax.plot(
            stft_time[::2],
            observed_peak[::2],
            linestyle="none",
            marker="o",
            markersize=1.9,
            markeredgewidth=0,
            color="#5cecff",
            alpha=0.82,
            label="observed spectral peak",
            zorder=5,
        )
    waterfall_ax.set_xlim(stft_time[0], stft_time[-1])
    waterfall_ax.set_ylim(-24.0, 22.0)
    waterfall_ax.set_ylabel("Frequency offset (Hz)")
    waterfall_ax.set_title(
        "Drifting narrowband signal: plasma displacement and broadening", pad=12
    )
    waterfall_ax.grid(False)
    waterfall_ax.tick_params(labelbottom=False)
    if show_tracks:
        waterfall_ax.legend(
            loc="upper left", frameon=False, fontsize=9, labelcolor="#dce6ec"
        )

    colorbar = fig.colorbar(waterfall_image, cax=colorbar_ax)
    colorbar.set_label("Power relative to median noise (dB)")
    colorbar.ax.tick_params(colors="#c8ced8")
    colorbar.outline.set_edgecolor("#aab2c0")

    delta_limit = max(0.6, float(np.nanpercentile(np.abs(delta_frequency), 99.0)) * 1.18)
    delta_ax.axhline(0.0, color="#ffffff", alpha=0.45, linewidth=0.8)
    delta_ax.plot(stft_time, delta_frequency, color="#5cecff", linewidth=1.15)
    delta_ax.fill_between(
        stft_time, 0.0, delta_frequency, color="#5cecff", alpha=0.16, linewidth=0
    )
    delta_ax.set_ylim(-delta_limit, delta_limit)
    delta_ax.set_ylabel(r"$\delta f(t)$ (Hz)")
    delta_ax.tick_params(labelbottom=False)

    width_top = max(0.5, float(np.nanpercentile(spectral_width, 99.0)) * 1.15)
    width_ax.plot(stft_time, spectral_width, color="#ffb45b", linewidth=1.2)
    width_ax.fill_between(
        stft_time, 0.0, spectral_width, color="#ffb45b", alpha=0.18, linewidth=0
    )
    width_ax.set_ylim(0.0, width_top)
    width_ax.set_ylabel(r"$\sigma_f(t)$ (Hz)")
    width_ax.set_xlabel("Time (s)")

    for diagnostic_ax in (delta_ax, width_ax):
        diagnostic_ax.grid(color="#aab2c0", alpha=0.14, linewidth=0.6)
        diagnostic_ax.set_xlim(stft_time[0], stft_time[-1])

    fig.savefig(output_path, dpi=180, facecolor=fig.get_facecolor())
    plt.close(fig)

    csv_path = output_path.with_suffix(".csv")
    np.savetxt(
        csv_path,
        np.column_stack(
            (
                stft_time,
                true_doppler_at_stft,
                observed_peak,
                delta_frequency,
                spectral_width,
            )
        ),
        delimiter=",",
        header="time_s,true_doppler_hz,observed_peak_hz,delta_f_hz,sigma_f_hz",
        comments="",
        fmt="%.8f",
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate a synthetic drifting and plasma-blurred SETI waterfall."
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_name("plasma_diagnostics_three_panel.png"),
        help="Destination PNG path.",
    )
    parser.add_argument("--seed", type=int, default=7, help="Random seed.")
    parser.add_argument(
        "--hide-tracks",
        action="store_true",
        help="Do not overlay the pre-plasma truth and measured spectral peaks.",
    )
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    make_figure(args.output, seed=args.seed, show_tracks=not args.hide_tracks)
    print(f"saved: {args.output.resolve()}")
    print(f"saved: {args.output.with_suffix('.csv').resolve()}")


if __name__ == "__main__":
    main()
